import 'package:arjun_s_application3/presentation/login_page_screen/login_page_screen.dart';
import 'package:arjun_s_application3/presentation/login_page_screen/binding/login_page_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_store_one_screen/farmer_store_one_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_store_one_screen/binding/farmer_store_one_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_main_menu_screen/farmer_main_menu_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_main_menu_screen/binding/farmer_main_menu_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_store_screen/farmer_store_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_store_screen/binding/farmer_store_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_sell_screen/farmer_sell_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_sell_screen/binding/farmer_sell_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_sell_customer_details_screen/farmer_sell_customer_details_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_sell_customer_details_screen/binding/farmer_sell_customer_details_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_successful_page_screen/farmer_successful_page_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_successful_page_screen/binding/farmer_successful_page_binding.dart';
import 'package:arjun_s_application3/presentation/phone_number_screen/phone_number_screen.dart';
import 'package:arjun_s_application3/presentation/phone_number_screen/binding/phone_number_binding.dart';
import 'package:arjun_s_application3/presentation/phone_number_one_screen/phone_number_one_screen.dart';
import 'package:arjun_s_application3/presentation/phone_number_one_screen/binding/phone_number_one_binding.dart';
import 'package:arjun_s_application3/presentation/base_selection_screen/base_selection_screen.dart';
import 'package:arjun_s_application3/presentation/base_selection_screen/binding/base_selection_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_personal_details_screen/farmer_selection_personal_details_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_personal_details_screen/binding/farmer_selection_personal_details_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_produce_details_screen/farmer_selection_produce_details_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_produce_details_screen/binding/farmer_selection_produce_details_binding.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_location_screen/farmer_selection_location_screen.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_location_screen/binding/farmer_selection_location_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_owner_details_screen/warehouse_owner_details_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_owner_details_screen/binding/warehouse_owner_details_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_add_screen/warehouse_add_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_add_screen/binding/warehouse_add_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_details_add_screen/warehouse_details_add_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_details_add_screen/binding/warehouse_details_add_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_location_screen/warehouse_location_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_location_screen/binding/warehouse_location_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_menu_screen/warehouse_menu_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_menu_screen/binding/warehouse_menu_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_one_screen/warehouse_one_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_one_screen/binding/warehouse_one_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_two_screen/warehouse_two_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_two_screen/binding/warehouse_two_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_page_screen/warehouse_request_page_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_page_screen/binding/warehouse_request_page_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_one_screen/warehouse_request_one_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_one_screen/binding/warehouse_request_one_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_two_screen/warehouse_request_two_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_two_screen/binding/warehouse_request_two_binding.dart';
import 'package:arjun_s_application3/presentation/warehouse_succeful_page_screen/warehouse_succeful_page_screen.dart';
import 'package:arjun_s_application3/presentation/warehouse_succeful_page_screen/binding/warehouse_succeful_page_binding.dart';
import 'package:arjun_s_application3/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:arjun_s_application3/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static const String loginPageScreen = '/login_page_screen';

  static const String farmerStoreOneScreen = '/farmer_store_one_screen';

  static const String farmerMainMenuScreen = '/farmer_main_menu_screen';

  static const String farmerStoreScreen = '/farmer_store_screen';

  static const String farmerSellScreen = '/farmer_sell_screen';

  static const String farmerSellCustomerDetailsScreen =
      '/farmer_sell_customer_details_screen';

  static const String farmerSuccessfulPageScreen =
      '/farmer_successful_page_screen';

  static const String phoneNumberScreen = '/phone_number_screen';

  static const String phoneNumberOneScreen = '/phone_number_one_screen';

  static const String baseSelectionScreen = '/base_selection_screen';

  static const String farmerSelectionPersonalDetailsScreen =
      '/farmer_selection_personal_details_screen';

  static const String farmerSelectionProduceDetailsScreen =
      '/farmer_selection_produce_details_screen';

  static const String farmerSelectionLocationScreen =
      '/farmer_selection_location_screen';

  static const String warehouseOwnerDetailsScreen =
      '/warehouse_owner_details_screen';

  static const String warehouseAddScreen = '/warehouse_add_screen';

  static const String warehouseDetailsAddScreen =
      '/warehouse_details_add_screen';

  static const String warehouseLocationScreen = '/warehouse_location_screen';

  static const String warehouseMenuScreen = '/warehouse_menu_screen';

  static const String warehouseOneScreen = '/warehouse_one_screen';

  static const String warehouseTwoScreen = '/warehouse_two_screen';

  static const String warehouseRequestPageScreen =
      '/warehouse_request_page_screen';

  static const String warehouseRequestOneScreen =
      '/warehouse_request_one_screen';

  static const String warehouseRequestTwoScreen =
      '/warehouse_request_two_screen';

  static const String warehouseSuccefulPageScreen =
      '/warehouse_succeful_page_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: loginPageScreen,
      page: () => LoginPageScreen(),
      bindings: [
        LoginPageBinding(),
      ],
    ),
    GetPage(
      name: farmerStoreOneScreen,
      page: () => FarmerStoreOneScreen(),
      bindings: [
        FarmerStoreOneBinding(),
      ],
    ),
    GetPage(
      name: farmerMainMenuScreen,
      page: () => FarmerMainMenuScreen(),
      bindings: [
        FarmerMainMenuBinding(),
      ],
    ),
    GetPage(
      name: farmerStoreScreen,
      page: () => FarmerStoreScreen(),
      bindings: [
        FarmerStoreBinding(),
      ],
    ),
    GetPage(
      name: farmerSellScreen,
      page: () => FarmerSellScreen(),
      bindings: [
        FarmerSellBinding(),
      ],
    ),
    GetPage(
      name: farmerSellCustomerDetailsScreen,
      page: () => FarmerSellCustomerDetailsScreen(),
      bindings: [
        FarmerSellCustomerDetailsBinding(),
      ],
    ),
    GetPage(
      name: farmerSuccessfulPageScreen,
      page: () => FarmerSuccessfulPageScreen(),
      bindings: [
        FarmerSuccessfulPageBinding(),
      ],
    ),
    GetPage(
      name: phoneNumberScreen,
      page: () => PhoneNumberScreen(),
      bindings: [
        PhoneNumberBinding(),
      ],
    ),
    GetPage(
      name: phoneNumberOneScreen,
      page: () => PhoneNumberOneScreen(),
      bindings: [
        PhoneNumberOneBinding(),
      ],
    ),
    GetPage(
      name: baseSelectionScreen,
      page: () => BaseSelectionScreen(),
      bindings: [
        BaseSelectionBinding(),
      ],
    ),
    GetPage(
      name: farmerSelectionPersonalDetailsScreen,
      page: () => FarmerSelectionPersonalDetailsScreen(),
      bindings: [
        FarmerSelectionPersonalDetailsBinding(),
      ],
    ),
    GetPage(
      name: farmerSelectionProduceDetailsScreen,
      page: () => FarmerSelectionProduceDetailsScreen(),
      bindings: [
        FarmerSelectionProduceDetailsBinding(),
      ],
    ),
    GetPage(
      name: farmerSelectionLocationScreen,
      page: () => FarmerSelectionLocationScreen(),
      bindings: [
        FarmerSelectionLocationBinding(),
      ],
    ),
    GetPage(
      name: warehouseOwnerDetailsScreen,
      page: () => WarehouseOwnerDetailsScreen(),
      bindings: [
        WarehouseOwnerDetailsBinding(),
      ],
    ),
    GetPage(
      name: warehouseAddScreen,
      page: () => WarehouseAddScreen(),
      bindings: [
        WarehouseAddBinding(),
      ],
    ),
    GetPage(
      name: warehouseDetailsAddScreen,
      page: () => WarehouseDetailsAddScreen(),
      bindings: [
        WarehouseDetailsAddBinding(),
      ],
    ),
    GetPage(
      name: warehouseLocationScreen,
      page: () => WarehouseLocationScreen(),
      bindings: [
        WarehouseLocationBinding(),
      ],
    ),
    GetPage(
      name: warehouseMenuScreen,
      page: () => WarehouseMenuScreen(),
      bindings: [
        WarehouseMenuBinding(),
      ],
    ),
    GetPage(
      name: warehouseOneScreen,
      page: () => WarehouseOneScreen(),
      bindings: [
        WarehouseOneBinding(),
      ],
    ),
    GetPage(
      name: warehouseTwoScreen,
      page: () => WarehouseTwoScreen(),
      bindings: [
        WarehouseTwoBinding(),
      ],
    ),
    GetPage(
      name: warehouseRequestPageScreen,
      page: () => WarehouseRequestPageScreen(),
      bindings: [
        WarehouseRequestPageBinding(),
      ],
    ),
    GetPage(
      name: warehouseRequestOneScreen,
      page: () => WarehouseRequestOneScreen(),
      bindings: [
        WarehouseRequestOneBinding(),
      ],
    ),
    GetPage(
      name: warehouseRequestTwoScreen,
      page: () => WarehouseRequestTwoScreen(),
      bindings: [
        WarehouseRequestTwoBinding(),
      ],
    ),
    GetPage(
      name: warehouseSuccefulPageScreen,
      page: () => WarehouseSuccefulPageScreen(),
      bindings: [
        WarehouseSuccefulPageBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => LoginPageScreen(),
      bindings: [
        LoginPageBinding(),
      ],
    )
  ];
}
