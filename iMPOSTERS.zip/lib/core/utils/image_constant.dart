class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Login Page images
  static String imgVector = '$imagePath/img_vector.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  // Farmer Main menu images
  static String imgSafalFasalRemovebgPreview =
      '$imagePath/img_safal_fasal_removebg_preview.png';

  // Base Selection images
  static String imgTwemojimanfarmerlightskintone =
      '$imagePath/img_twemojimanfarmerlightskintone.svg';

  static String imgPhwarehousefill = '$imagePath/img_phwarehousefill.svg';

  // Farmer Selection (Produce Details) images
  static String imgSearch = '$imagePath/img_search.svg';

  static String imgTdesignMoney = '$imagePath/img_tdesign_money.svg';

  // Warehouse Details (ADD) images
  static String imgBxsarea = '$imagePath/img_bxsarea.svg';

  // Warehouse Menu images
  static String imgSafalFasalRemovebgPreview66x390 =
      '$imagePath/img_safal_fasal_removebg_preview_66x390.png';

  // Common images
  static String imgSafalFasal1 = '$imagePath/img_safal_fasal_1.png';

  static String imgCall = '$imagePath/img_call.svg';

  static String imgJamMenu = '$imagePath/img_jam_menu.svg';

  static String imgVectorPrimarycontainer =
      '$imagePath/img_vector_primarycontainer.svg';

  static String imgSolarCalendarBroken =
      '$imagePath/img_solar_calendar_broken.svg';

  static String imgLocation = '$imagePath/img_location.svg';

  static String imgMaterialSymbol = '$imagePath/img_material_symbol.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
