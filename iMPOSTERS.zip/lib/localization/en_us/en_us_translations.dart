final Map<String, String> enUs = {
  // Login Page Screen
  "lbl": "*********",
  "lbl_log_in": "LOG IN",
  "lbl_no_account": "No account? | ",
  "lbl_phone_number": "Phone Number",
  "lbl_sign_up": "sign up ",
  "msg_forgot_password": "forgot password?",
  "msg_no_account_sign": "No account? | sign up ",

  // Farmer Store One Screen
  "lbl_back": "Back",
  "lbl_guntur": " : Guntur\n\n",
  "msg_items_stored_bajra":
      "Items stored- Bajra, Rice\nQuantity Stored- 10 Quintals, 8 Quintals",
  "msg_items_stored_wheet":
      "Items stored- Wheet, Rice\nQuantity Stored- 7 Quintals, 6 Quintals",
  "msg_location_guntur": "Location : Guntur\n\n",

  // Farmer Main menu Screen
  "lbl_ann_devta": "Ann-devta!",
  "lbl_choose_option": "Choose Option",
  "lbl_go_back": "go back",
  "lbl_sell": "Sell",
  "lbl_store": "Store",
  "lbl_view_stock": "View Stock",
  "msg_we_hope_you_have": "we hope you have a good yeild.",

  // Farmer Store Screen
  "lbl_which_warehouse": "Which Warehouse",
  "msg_quantity_to_be_stored": "Quantity to be stored",
  "msg_what_do_you_want": "What do you want to store",

  // Farmer Sell Screen
  "msg_from_which_warehouse": " From which Warehouse",
  "msg_quantity_to_be_sold": "Quantity to be sold",
  "msg_what_do_you_want2": "What do you want to sell",

  // Farmer Sell Customer Details Screen
  "lbl_customer_name": "Customer Name", "lbl_order_id": "Order ID",
  "lbl_submit": "Submit", "msg_customer_contact": "Customer Contact",

  // Phone Number One Screen
  "lbl_create_account": "Create Account",
  "lbl_create_password": "Create Password",
  "msg_enter_a_new_password": "Enter a new Password",

  // Base Selection Screen
  "lbl_farmer": "Farmer",
  "msg_which_one_of_the": "Which one of the following describes you the best?",

  // Farmer Selection (Produce Details) Screen
  "msg_enter_wright_in": "(enter wright in tons)",
  "msg_how_much_do_you": "How much do you produce in an year? (Approx.)",
  "msg_how_much_do_you2": "How much do you spend on storage in an year?",
  "msg_what_do_you_mainly": "What do you mainly produce?",

  // Warehouse Add Screen
  "lbl_add_a_warehouse": "Add a Warehouse", "lbl_warehouses": "Warehouses",

  // Warehouse Details (ADD) Screen
  "msg_enter_maximum_space": "(enter maximum space)",
  "msg_maximum_storage": "Maximum Storage of your Warehouse",
  "msg_name_of_your_warehouse": "Name of your warehouse",
  "msg_space_available": "Space available currently",

  // Warehouse Menu Screen
  "lbl_burdwan": " : Burdwan",
  "lbl_view": "View",
  "lbl_view_requests": "View Requests",
  "lbl_your_warehouses": "Your Warehouses",
  "msg_location_burdwan": "Location : Burdwan",
  "msg_we_hope_you_have2": "we hope you have a nice day.",

  // Warehouse One Screen
  "msg_occupied_space": "Occupied Space- 5000 Quintals",
  "msg_total_capacity": "Total  capacity- 15000 Quintals",

  // Warehouse Two Screen
  "msg_occupied_space_8000": "Occupied Space-8000 Quintals",
  "msg_total_capacity2": "Total  capacity- 10000 Quintals",

  // Warehouse Request Page Screen
  "lbl_requests": "Requests",

  // Warehouse Request One Screen
  "lbl_quantity": "Quantity",

  // Warehouse Request Two Screen
  "lbl_quantity2": "Quantity ",

  // Common String
  "lbl_approve_request": "Approve Request",
  "lbl_contact_us": "Contact us",
  "lbl_date_of_birth": "Date of Birth",
  "lbl_enter_amount": "(enter amount)",
  "lbl_farmer_s_name": "Farmer’s Name",
  "lbl_female": "Female",
  "lbl_full_name": "Full Name",
  "lbl_item": " item ",
  "lbl_kota": " : Kota\n\n",
  "lbl_list_of_farmers": "List of Farmers",
  "lbl_location": "Location",
  "lbl_location_kota": "Location : Kota\n\n",
  "lbl_male": "Male",
  "lbl_next": "Next",
  "lbl_request_1": "Request 1",
  "lbl_request_2": "Request 2",
  "lbl_request_type": "Request type",
  "lbl_return": "Return",
  "lbl_return_to_home": "Return to Home",
  "lbl_sign_in": "sign in ",
  "lbl_stored_items": "Stored Items",
  "lbl_warehouse": "Warehouse",
  "lbl_warehouse_1": "Warehouse 1",
  "lbl_warehouse_2": "Warehouse 2",
  "lbl_welcome": "WELCOME",
  "lbl_welcome_back": "Welcome back,",
  "msg_already_have_an": "Already have an account? | sign in ",
  "msg_already_have_an2": "Already have an account? | ",
  "msg_enter_your_location": "Enter your location",
  "msg_enter_your_phone": "Enter your phone number",
  "msg_fill_in_the_following": "Fill in the following details to proceed",
  "msg_locate_me_automatically": "Locate me automatically",
  "msg_request_processed": "Request Processed!",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_password": "Please enter valid password",
  "err_msg_please_enter_valid_phone_number": "Please enter valid phone number",
  "err_msg_please_enter_valid_text": "Please enter valid text",
};
