import 'package:flutter/material.dart';
import '../core/app_export.dart';

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// Additionally, this class includes extensions on [TextStyle] to easily apply specific font families to text.

class CustomTextStyles {
  // Body text style
  static get bodyLargeBlue500 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.blue500,
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeBlue700 => theme.textTheme.bodyLarge!.copyWith(
        color: appTheme.blue700,
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeLight => theme.textTheme.bodyLarge!.copyWith(
        fontWeight: FontWeight.w300,
      );
  static get bodyLargeOnPrimary => theme.textTheme.bodyLarge!.copyWith(
        color: theme.colorScheme.onPrimary,
      );
  static get bodyLargePrimaryContainer => theme.textTheme.bodyLarge!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(0.62),
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeRegular => theme.textTheme.bodyLarge!.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeRegular_1 => theme.textTheme.bodyLarge!.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeSFProDisplay =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        fontWeight: FontWeight.w200,
      );
  static get bodyLargeSFProDisplayExtraLight =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        fontSize: 18.fSize,
        fontWeight: FontWeight.w200,
      );
  static get bodyLargeSFProDisplayLight =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        fontSize: 18.fSize,
        fontWeight: FontWeight.w300,
      );
  static get bodyLargeSFProDisplayPrimaryContainer =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(0.62),
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeSFProDisplayPrimaryContainerLight =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(0.49),
        fontSize: 19.fSize,
        fontWeight: FontWeight.w300,
      );
  static get bodyLargeSFProDisplayPrimaryContainerRegular =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        color: theme.colorScheme.primaryContainer,
        fontWeight: FontWeight.w400,
      );
  static get bodyLargeSFProDisplayRegular =>
      theme.textTheme.bodyLarge!.sFProDisplay.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get bodySmallRegular => theme.textTheme.bodySmall!.copyWith(
        fontSize: 12.fSize,
        fontWeight: FontWeight.w400,
      );
  // Display text style
  static get displaySmallSemiBold => theme.textTheme.displaySmall!.copyWith(
        fontWeight: FontWeight.w600,
      );
  // Headline text style
  static get headlineLargeSFProDisplay =>
      theme.textTheme.headlineLarge!.sFProDisplay.copyWith(
        fontSize: 30.fSize,
        fontWeight: FontWeight.w600,
      );
  // Title text style
  static get titleLargeRegular => theme.textTheme.titleLarge!.copyWith(
        fontWeight: FontWeight.w400,
      );
  static get titleLargeSFProDisplay =>
      theme.textTheme.titleLarge!.sFProDisplay.copyWith(
        fontSize: 21.fSize,
        fontWeight: FontWeight.w200,
      );
  static get titleLargeSemiBold => theme.textTheme.titleLarge!.copyWith(
        fontWeight: FontWeight.w600,
      );
  static get titleMediumPrimaryContainer =>
      theme.textTheme.titleMedium!.copyWith(
        color: theme.colorScheme.primaryContainer.withOpacity(0.49),
        fontSize: 19.fSize,
      );
}

extension on TextStyle {
  TextStyle get shipporiMincho {
    return copyWith(
      fontFamily: 'Shippori Mincho',
    );
  }

  TextStyle get inter {
    return copyWith(
      fontFamily: 'Inter',
    );
  }

  TextStyle get sFProDisplay {
    return copyWith(
      fontFamily: 'SF Pro Display',
    );
  }
}
