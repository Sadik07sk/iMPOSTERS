import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/base_selection_screen/models/base_selection_model.dart';

/// A controller class for the BaseSelectionScreen.
///
/// This class manages the state of the BaseSelectionScreen, including the
/// current baseSelectionModelObj
class BaseSelectionController extends GetxController {
  Rx<BaseSelectionModel> baseSelectionModelObj = BaseSelectionModel().obs;
}
