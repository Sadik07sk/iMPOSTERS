import '../controller/base_selection_controller.dart';
import 'package:get/get.dart';

/// A binding class for the BaseSelectionScreen.
///
/// This class ensures that the BaseSelectionController is created when the
/// BaseSelectionScreen is first loaded.
class BaseSelectionBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BaseSelectionController());
  }
}
