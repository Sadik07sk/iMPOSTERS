import 'controller/base_selection_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class BaseSelectionScreen extends GetWidget<BaseSelectionController> {
  const BaseSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 38.h, vertical: 10.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomImageView(
                                  imagePath: ImageConstant.imgSafalFasal1,
                                  height: 219.v,
                                  width: 305.h),
                              SizedBox(height: 27.v),
                              Align(
                                  alignment: Alignment.center,
                                  child: Container(
                                      width: 275.h,
                                      margin: EdgeInsets.only(
                                          left: 14.h, right: 23.h),
                                      child: Text("msg_which_one_of_the".tr,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                          textAlign: TextAlign.center,
                                          style: CustomTextStyles
                                              .bodyLargeLight))),
                              SizedBox(height: 25.v),
                              CustomElevatedButton(
                                  height: 50.v,
                                  text: "lbl_farmer".tr,
                                  margin:
                                      EdgeInsets.only(left: 11.h, right: 21.h),
                                  leftIcon: Container(
                                      margin: EdgeInsets.only(right: 9.h),
                                      child: CustomImageView(
                                          imagePath: ImageConstant
                                              .imgTwemojimanfarmerlightskintone,
                                          height: 32.v,
                                          width: 37.h)),
                                  buttonStyle:
                                      CustomButtonStyles.outlinePrimary,
                                  buttonTextStyle:
                                      CustomTextStyles.titleLargeRegular,
                                  onPressed: () {
                                    onTapFarmer();
                                  }),
                              SizedBox(height: 23.v),
                              CustomElevatedButton(
                                  height: 50.v,
                                  text: "lbl_warehouse".tr,
                                  margin:
                                      EdgeInsets.only(left: 11.h, right: 21.h),
                                  leftIcon: Container(
                                      margin: EdgeInsets.only(right: 8.h),
                                      child: CustomImageView(
                                          imagePath:
                                              ImageConstant.imgPhwarehousefill,
                                          height: 43.v,
                                          width: 31.h)),
                                  buttonStyle:
                                      CustomButtonStyles.outlinePrimary,
                                  buttonTextStyle:
                                      CustomTextStyles.titleLargeRegular,
                                  onPressed: () {
                                    onTapWarehouse();
                                  }),
                              SizedBox(height: 318.v),
                              Align(
                                  alignment: Alignment.center,
                                  child: GestureDetector(
                                      onTap: () {
                                        onTapTxtAlreadyhavean();
                                      },
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "msg_already_have_an2".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeRegular),
                                            TextSpan(
                                                text: "lbl_sign_in".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeBlue500)
                                          ]),
                                          textAlign: TextAlign.left))),
                              SizedBox(height: 47.v)
                            ]))))));
  }

  /// Navigates to the farmerSelectionPersonalDetailsScreen when the action is triggered.
  onTapFarmer() {
    Get.toNamed(
      AppRoutes.farmerSelectionPersonalDetailsScreen,
    );
  }

  /// Navigates to the warehouseOwnerDetailsScreen when the action is triggered.
  onTapWarehouse() {
    Get.toNamed(
      AppRoutes.warehouseOwnerDetailsScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
