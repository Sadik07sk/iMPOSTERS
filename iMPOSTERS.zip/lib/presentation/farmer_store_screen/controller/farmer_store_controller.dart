import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_store_screen/models/farmer_store_model.dart';

/// A controller class for the FarmerStoreScreen.
///
/// This class manages the state of the FarmerStoreScreen, including the
/// current farmerStoreModelObj
class FarmerStoreController extends GetxController {
  Rx<FarmerStoreModel> farmerStoreModelObj = FarmerStoreModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  SelectionPopupModel? selectedDropDownValue2;

  onSelected(dynamic value) {
    for (var element in farmerStoreModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerStoreModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    for (var element in farmerStoreModelObj.value.dropdownItemList1.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerStoreModelObj.value.dropdownItemList1.refresh();
  }

  onSelected2(dynamic value) {
    for (var element in farmerStoreModelObj.value.dropdownItemList2.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerStoreModelObj.value.dropdownItemList2.refresh();
  }
}
