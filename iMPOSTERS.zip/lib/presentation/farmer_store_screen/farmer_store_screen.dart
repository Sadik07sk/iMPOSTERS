import 'controller/farmer_store_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_drop_down.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerStoreScreen extends GetWidget<FarmerStoreController> {
  const FarmerStoreScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 42.h, vertical: 67.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(height: 46.v),
                              CustomImageView(
                                  imagePath: ImageConstant.imgSafalFasal1,
                                  height: 219.v,
                                  width: 305.h),
                              SizedBox(height: 47.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 2.h, right: 12.h),
                                  child: CustomDropDown(
                                      icon: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              10.h, 9.v, 24.h, 9.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgVectorPrimarycontainer,
                                              height: 5.v,
                                              width: 10.h)),
                                      hintText: "msg_what_do_you_want".tr,
                                      items: controller.farmerStoreModelObj
                                          .value.dropdownItemList!.value,
                                      onChanged: (value) {
                                        controller.onSelected(value);
                                      })),
                              SizedBox(height: 24.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 2.h, right: 12.h),
                                  child: CustomDropDown(
                                      icon: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              29.h, 11.v, 24.h, 11.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgVectorPrimarycontainer,
                                              height: 5.v,
                                              width: 10.h)),
                                      hintText: "msg_quantity_to_be_stored".tr,
                                      items: controller.farmerStoreModelObj
                                          .value.dropdownItemList1!.value,
                                      onChanged: (value) {
                                        controller.onSelected1(value);
                                      })),
                              SizedBox(height: 20.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 2.h, right: 12.h),
                                  child: CustomDropDown(
                                      icon: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              30.h, 11.v, 24.h, 11.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgVectorPrimarycontainer,
                                              height: 5.v,
                                              width: 10.h)),
                                      hintText: "lbl_which_warehouse".tr,
                                      items: controller.farmerStoreModelObj
                                          .value.dropdownItemList2!.value,
                                      onChanged: (value) {
                                        controller.onSelected2(value);
                                      })),
                              SizedBox(height: 238.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_next".tr,
                                  onPressed: () {
                                    onTapNext();
                                  },
                                  alignment: Alignment.center)
                            ]))))));
  }

  /// Navigates to the farmerSuccessfulPageScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.farmerSuccessfulPageScreen,
    );
  }
}
