import '../controller/farmer_store_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerStoreScreen.
///
/// This class ensures that the FarmerStoreController is created when the
/// FarmerStoreScreen is first loaded.
class FarmerStoreBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerStoreController());
  }
}
