import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_location_screen/models/warehouse_location_model.dart';

/// A controller class for the WarehouseLocationScreen.
///
/// This class manages the state of the WarehouseLocationScreen, including the
/// current warehouseLocationModelObj
class WarehouseLocationController extends GetxController {
  Rx<WarehouseLocationModel> warehouseLocationModelObj =
      WarehouseLocationModel().obs;
}
