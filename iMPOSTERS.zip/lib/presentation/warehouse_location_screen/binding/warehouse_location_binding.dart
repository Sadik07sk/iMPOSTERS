import '../controller/warehouse_location_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseLocationScreen.
///
/// This class ensures that the WarehouseLocationController is created when the
/// WarehouseLocationScreen is first loaded.
class WarehouseLocationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseLocationController());
  }
}
