import '../controller/warehouse_one_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseOneScreen.
///
/// This class ensures that the WarehouseOneController is created when the
/// WarehouseOneScreen is first loaded.
class WarehouseOneBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseOneController());
  }
}
