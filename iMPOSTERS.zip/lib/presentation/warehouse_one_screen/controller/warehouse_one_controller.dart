import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_one_screen/models/warehouse_one_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseOneScreen.
///
/// This class manages the state of the WarehouseOneScreen, including the
/// current warehouseOneModelObj
class WarehouseOneController extends GetxController {
  TextEditingController cityController = TextEditingController();

  TextEditingController eighteenController = TextEditingController();

  Rx<WarehouseOneModel> warehouseOneModelObj = WarehouseOneModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  @override
  void onClose() {
    super.onClose();
    cityController.dispose();
    eighteenController.dispose();
  }

  onSelected(dynamic value) {
    for (var element in warehouseOneModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    warehouseOneModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    for (var element in warehouseOneModelObj.value.dropdownItemList1.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    warehouseOneModelObj.value.dropdownItemList1.refresh();
  }
}
