import '../controller/farmer_main_menu_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerMainMenuScreen.
///
/// This class ensures that the FarmerMainMenuController is created when the
/// FarmerMainMenuScreen is first loaded.
class FarmerMainMenuBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerMainMenuController());
  }
}
