import 'controller/farmer_main_menu_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerMainMenuScreen extends GetWidget<FarmerMainMenuController> {
  const FarmerMainMenuScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 5.v),
                child: Column(children: [
                  SizedBox(height: 10.v),
                  CustomImageView(
                      imagePath: ImageConstant.imgJamMenu,
                      height: 43.v,
                      width: 44.h,
                      alignment: Alignment.centerLeft,
                      margin: EdgeInsets.only(left: 10.h)),
                  SizedBox(height: 37.v),
                  _buildWelcomeBackSection(),
                  SizedBox(height: 22.v),
                  _buildNinetyNineSection(),
                  SizedBox(height: 92.v),
                  CustomImageView(
                      imagePath: ImageConstant.imgSafalFasalRemovebgPreview,
                      height: 66.v,
                      width: 390.h),
                  SizedBox(height: 55.v),
                  GestureDetector(
                      onTap: () {
                        onTapTxtGoBack();
                      },
                      child: Text("lbl_go_back".tr,
                          style: CustomTextStyles.bodySmallRegular))
                ]))));
  }

  /// Section Widget
  Widget _buildWelcomeBackSection() {
    return Container(
        width: 335.h,
        margin: EdgeInsets.symmetric(horizontal: 27.h),
        padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 41.v),
        decoration: AppDecoration.outlinePrimary2
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder6),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                  height: 89.v,
                  width: 228.h,
                  child: Stack(alignment: Alignment.bottomLeft, children: [
                    Align(
                        alignment: Alignment.topCenter,
                        child: Text("lbl_welcome_back".tr,
                            style: theme.textTheme.displaySmall)),
                    Align(
                        alignment: Alignment.bottomLeft,
                        child: Text("lbl_ann_devta".tr,
                            style: CustomTextStyles.displaySmallSemiBold))
                  ])),
              SizedBox(height: 2.v),
              Text("msg_we_hope_you_have".tr,
                  style: CustomTextStyles.titleLargeSFProDisplay),
              SizedBox(height: 10.v)
            ]));
  }

  /// Section Widget
  Widget _buildNinetyNineSection() {
    return Container(
        width: 326.h,
        margin: EdgeInsets.only(left: 37.h, right: 27.h),
        padding: EdgeInsets.symmetric(horizontal: 27.h, vertical: 18.v),
        decoration: AppDecoration.outlinePrimary1
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder6),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                  padding: EdgeInsets.only(left: 60.h),
                  child: Text("lbl_choose_option".tr,
                      style: CustomTextStyles.titleLargeSFProDisplay))),
          SizedBox(height: 14.v),
          CustomElevatedButton(
              height: 50.v,
              text: "lbl_store".tr,
              margin: EdgeInsets.only(left: 10.h),
              buttonStyle: CustomButtonStyles.outlinePrimary,
              buttonTextStyle: theme.textTheme.titleLarge!,
              onPressed: () {
                onTapStore();
              }),
          SizedBox(height: 17.v),
          CustomElevatedButton(
              height: 50.v,
              text: "lbl_sell".tr,
              margin: EdgeInsets.only(left: 10.h),
              buttonStyle: CustomButtonStyles.outlinePrimary,
              buttonTextStyle: theme.textTheme.titleLarge!,
              onPressed: () {
                onTapSell();
              }),
          SizedBox(height: 17.v),
          CustomElevatedButton(
              height: 50.v,
              text: "lbl_view_stock".tr,
              margin: EdgeInsets.only(left: 10.h),
              buttonStyle: CustomButtonStyles.outlinePrimary,
              buttonTextStyle: theme.textTheme.titleLarge!,
              onPressed: () {
                onTapViewStock();
              }),
          SizedBox(height: 17.v)
        ]));
  }

  /// Navigates to the farmerStoreScreen when the action is triggered.
  onTapStore() {
    Get.toNamed(
      AppRoutes.farmerStoreScreen,
    );
  }

  /// Navigates to the farmerSellScreen when the action is triggered.
  onTapSell() {
    Get.toNamed(
      AppRoutes.farmerSellScreen,
    );
  }

  /// Navigates to the farmerStoreOneScreen when the action is triggered.
  onTapViewStock() {
    Get.toNamed(
      AppRoutes.farmerStoreOneScreen,
    );
  }

  /// Navigates to the baseSelectionScreen when the action is triggered.
  onTapTxtGoBack() {
    Get.toNamed(
      AppRoutes.baseSelectionScreen,
    );
  }
}
