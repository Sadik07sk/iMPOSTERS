import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_main_menu_screen/models/farmer_main_menu_model.dart';

/// A controller class for the FarmerMainMenuScreen.
///
/// This class manages the state of the FarmerMainMenuScreen, including the
/// current farmerMainMenuModelObj
class FarmerMainMenuController extends GetxController {
  Rx<FarmerMainMenuModel> farmerMainMenuModelObj = FarmerMainMenuModel().obs;
}
