import '../controller/warehouse_add_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseAddScreen.
///
/// This class ensures that the WarehouseAddController is created when the
/// WarehouseAddScreen is first loaded.
class WarehouseAddBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseAddController());
  }
}
