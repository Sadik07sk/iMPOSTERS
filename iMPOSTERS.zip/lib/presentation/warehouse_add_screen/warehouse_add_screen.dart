import 'controller/warehouse_add_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class WarehouseAddScreen extends GetWidget<WarehouseAddController> {
  const WarehouseAddScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 37.h, vertical: 59.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(height: 62.v),
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: SizedBox(
                                      height: 243.v,
                                      width: 305.h,
                                      child: Stack(
                                          alignment: Alignment.bottomRight,
                                          children: [
                                            CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgSafalFasal1,
                                                height: 219.v,
                                                width: 305.h,
                                                alignment: Alignment.topCenter),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        right: 54.h),
                                                    child: Text(
                                                        "lbl_warehouses".tr,
                                                        style: theme.textTheme
                                                            .headlineLarge)))
                                          ]))),
                              SizedBox(height: 13.v),
                              Padding(
                                  padding:
                                      EdgeInsets.symmetric(horizontal: 12.h),
                                  child: CustomTextFormField(
                                      controller:
                                          controller.addaWarehouseController,
                                      hintText: "lbl_add_a_warehouse".tr,
                                      textInputAction: TextInputAction.done)),
                              SizedBox(height: 35.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_next".tr,
                                  onPressed: () {
                                    onTapNext();
                                  }),
                              SizedBox(height: 290.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_already_have_an2".tr,
                                            style: CustomTextStyles
                                                .bodyLargeRegular),
                                        TextSpan(
                                            text: "lbl_sign_in".tr,
                                            style: CustomTextStyles
                                                .bodyLargeBlue500)
                                      ]),
                                      textAlign: TextAlign.left))
                            ]))))));
  }

  /// Navigates to the warehouseDetailsAddScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.warehouseDetailsAddScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
