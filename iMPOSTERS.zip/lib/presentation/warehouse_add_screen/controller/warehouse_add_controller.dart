import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_add_screen/models/warehouse_add_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseAddScreen.
///
/// This class manages the state of the WarehouseAddScreen, including the
/// current warehouseAddModelObj
class WarehouseAddController extends GetxController {
  TextEditingController addaWarehouseController = TextEditingController();

  Rx<WarehouseAddModel> warehouseAddModelObj = WarehouseAddModel().obs;

  @override
  void onClose() {
    super.onClose();
    addaWarehouseController.dispose();
  }
}
