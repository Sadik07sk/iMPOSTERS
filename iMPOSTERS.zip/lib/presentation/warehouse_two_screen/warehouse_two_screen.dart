import 'controller/warehouse_two_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_drop_down.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class WarehouseTwoScreen extends GetWidget<WarehouseTwoController> {
  const WarehouseTwoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 37.h, vertical: 70.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(height: 52.v),
                              SizedBox(
                                  height: 242.v,
                                  width: 305.h,
                                  child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgSafalFasal1,
                                            height: 219.v,
                                            width: 305.h,
                                            alignment: Alignment.topCenter),
                                        Align(
                                            alignment: Alignment.bottomRight,
                                            child: Padding(
                                                padding: EdgeInsets.only(
                                                    right: 48.h),
                                                child: Text(
                                                    "lbl_warehouse_2".tr,
                                                    style: theme.textTheme
                                                        .headlineLarge)))
                                      ])),
                              SizedBox(height: 14.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 7.h, right: 17.h),
                                  child: CustomTextFormField(
                                      controller: controller.cityController,
                                      hintText: "msg_total_capacity2".tr)),
                              SizedBox(height: 24.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 7.h, right: 17.h),
                                  child: CustomTextFormField(
                                      controller:
                                          controller.thirtyThreeController,
                                      hintText: "msg_occupied_space_8000".tr,
                                      textInputAction: TextInputAction.done)),
                              SizedBox(height: 20.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 7.h, right: 17.h),
                                  child: CustomDropDown(
                                      icon: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              30.h, 11.v, 24.h, 11.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgVectorPrimarycontainer,
                                              height: 5.v,
                                              width: 10.h)),
                                      hintText: "lbl_stored_items".tr,
                                      items: controller.warehouseTwoModelObj
                                          .value.dropdownItemList!.value,
                                      onChanged: (value) {
                                        controller.onSelected(value);
                                      })),
                              SizedBox(height: 20.v),
                              Padding(
                                  padding:
                                      EdgeInsets.only(left: 7.h, right: 17.h),
                                  child: CustomDropDown(
                                      icon: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              30.h, 9.v, 24.h, 9.v),
                                          child: CustomImageView(
                                              imagePath: ImageConstant
                                                  .imgVectorPrimarycontainer,
                                              height: 5.v,
                                              width: 10.h)),
                                      hintText: "lbl_list_of_farmers".tr,
                                      items: controller.warehouseTwoModelObj
                                          .value.dropdownItemList1!.value,
                                      onChanged: (value) {
                                        controller.onSelected1(value);
                                      })),
                              SizedBox(height: 187.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_return".tr,
                                  onPressed: () {
                                    onTapReturn();
                                  },
                                  alignment: Alignment.center)
                            ]))))));
  }

  /// Navigates to the warehouseMenuScreen when the action is triggered.
  onTapReturn() {
    Get.toNamed(
      AppRoutes.warehouseMenuScreen,
    );
  }
}
