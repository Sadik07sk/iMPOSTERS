import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_two_screen/models/warehouse_two_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseTwoScreen.
///
/// This class manages the state of the WarehouseTwoScreen, including the
/// current warehouseTwoModelObj
class WarehouseTwoController extends GetxController {
  TextEditingController cityController = TextEditingController();

  TextEditingController thirtyThreeController = TextEditingController();

  Rx<WarehouseTwoModel> warehouseTwoModelObj = WarehouseTwoModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  @override
  void onClose() {
    super.onClose();
    cityController.dispose();
    thirtyThreeController.dispose();
  }

  onSelected(dynamic value) {
    for (var element in warehouseTwoModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    warehouseTwoModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    for (var element in warehouseTwoModelObj.value.dropdownItemList1.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    warehouseTwoModelObj.value.dropdownItemList1.refresh();
  }
}
