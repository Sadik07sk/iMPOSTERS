import 'controller/warehouse_details_add_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class WarehouseDetailsAddScreen
    extends GetWidget<WarehouseDetailsAddController> {
  const WarehouseDetailsAddScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 38.h, vertical: 10.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(children: [
                          SizedBox(
                              height: 224.v,
                              width: 305.h,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgSafalFasal1,
                                        height: 219.v,
                                        width: 305.h,
                                        alignment: Alignment.center),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Text(
                                            "msg_fill_in_the_following".tr,
                                            style: CustomTextStyles
                                                .bodyLargeLight))
                                  ])),
                          SizedBox(height: 38.v),
                          Text("msg_name_of_your_warehouse".tr,
                              style: theme.textTheme.bodyLarge),
                          SizedBox(height: 1.v),
                          Padding(
                              padding: EdgeInsets.symmetric(horizontal: 11.h),
                              child: CustomTextFormField(
                                  controller: controller.editTextController,
                                  borderDecoration: TextFormFieldStyleHelper
                                      .outlinePrimaryTL14,
                                  fillColor:
                                      appTheme.blueGray100.withOpacity(0.64))),
                          SizedBox(height: 20.v),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                  padding: EdgeInsets.only(right: 9.h),
                                  child: Text("msg_maximum_storage".tr,
                                      textAlign: TextAlign.center,
                                      style: theme.textTheme.bodyLarge))),
                          SizedBox(height: 3.v),
                          Padding(
                              padding: EdgeInsets.symmetric(horizontal: 11.h),
                              child: CustomTextFormField(
                                  controller: controller.bxsareaController,
                                  hintText: "msg_enter_maximum_space".tr,
                                  hintStyle: theme.textTheme.bodyMedium!,
                                  textInputAction: TextInputAction.done,
                                  prefix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                          16.h, 3.v, 30.h, 4.v),
                                      child: CustomImageView(
                                          imagePath: ImageConstant.imgBxsarea,
                                          height: 21.v,
                                          width: 22.h)),
                                  prefixConstraints:
                                      BoxConstraints(maxHeight: 28.v),
                                  contentPadding: EdgeInsets.only(
                                      top: 6.v, right: 30.h, bottom: 6.v))),
                          SizedBox(height: 17.v),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                  padding: EdgeInsets.only(right: 54.h),
                                  child: Text("msg_space_available".tr,
                                      textAlign: TextAlign.center,
                                      style: theme.textTheme.bodyLarge))),
                          SizedBox(height: 6.v),
                          Container(
                              margin: EdgeInsets.only(left: 15.h, right: 7.h),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12.h, vertical: 3.v),
                              decoration: AppDecoration.outlinePrimary.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder15),
                              child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Opacity(
                                        opacity: 0.54,
                                        child: CustomImageView(
                                            imagePath: ImageConstant.imgBxsarea,
                                            height: 21.v,
                                            width: 22.h,
                                            margin: EdgeInsets.only(top: 1.v))),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 75.h, top: 3.v, bottom: 2.v),
                                        child: Text("lbl_enter_amount".tr,
                                            style: theme.textTheme.bodyMedium))
                                  ])),
                          SizedBox(height: 141.v),
                          CustomElevatedButton(
                              width: 177.h,
                              text: "lbl_next".tr,
                              margin: EdgeInsets.only(right: 58.h),
                              onPressed: () {
                                onTapNext();
                              },
                              alignment: Alignment.centerRight),
                          SizedBox(height: 127.v),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: Padding(
                                      padding: EdgeInsets.only(left: 22.h),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "msg_already_have_an2".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeRegular),
                                            TextSpan(
                                                text: "lbl_sign_in".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeBlue500)
                                          ]),
                                          textAlign: TextAlign.left)))),
                          SizedBox(height: 46.v)
                        ]))))));
  }

  /// Navigates to the warehouseLocationScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.warehouseLocationScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
