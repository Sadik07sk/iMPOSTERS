import '../controller/warehouse_details_add_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseDetailsAddScreen.
///
/// This class ensures that the WarehouseDetailsAddController is created when the
/// WarehouseDetailsAddScreen is first loaded.
class WarehouseDetailsAddBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseDetailsAddController());
  }
}
