import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_details_add_screen/models/warehouse_details_add_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseDetailsAddScreen.
///
/// This class manages the state of the WarehouseDetailsAddScreen, including the
/// current warehouseDetailsAddModelObj
class WarehouseDetailsAddController extends GetxController {
  TextEditingController editTextController = TextEditingController();

  TextEditingController bxsareaController = TextEditingController();

  Rx<WarehouseDetailsAddModel> warehouseDetailsAddModelObj =
      WarehouseDetailsAddModel().obs;

  @override
  void onClose() {
    super.onClose();
    editTextController.dispose();
    bxsareaController.dispose();
  }
}
