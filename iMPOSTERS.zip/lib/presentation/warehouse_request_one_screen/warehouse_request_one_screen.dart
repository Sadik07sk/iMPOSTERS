import 'controller/warehouse_request_one_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/core/utils/validation_functions.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class WarehouseRequestOneScreen
    extends GetWidget<WarehouseRequestOneController> {
  WarehouseRequestOneScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 37.h, vertical: 107.v),
                            decoration: AppDecoration.fillGreen,
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 15.v),
                                  SizedBox(
                                      height: 246.v,
                                      width: 305.h,
                                      child: Stack(
                                          alignment: Alignment.bottomRight,
                                          children: [
                                            CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgSafalFasal1,
                                                height: 219.v,
                                                width: 305.h,
                                                alignment: Alignment.topCenter),
                                            Align(
                                                alignment:
                                                    Alignment.bottomRight,
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        right: 72.h),
                                                    child: Text(
                                                        "lbl_request_1".tr,
                                                        style: theme.textTheme
                                                            .headlineLarge)))
                                          ])),
                                  SizedBox(height: 10.v),
                                  Padding(
                                      padding: EdgeInsets.only(
                                          left: 7.h, right: 17.h),
                                      child: CustomTextFormField(
                                          controller: controller.nameController,
                                          hintText: "lbl_farmer_s_name".tr,
                                          textInputAction: TextInputAction.done,
                                          validator: (value) {
                                            if (!isText(value)) {
                                              return "err_msg_please_enter_valid_text"
                                                  .tr;
                                            }
                                            return null;
                                          })),
                                  SizedBox(height: 24.v),
                                  Container(
                                      width: 292.h,
                                      margin: EdgeInsets.only(left: 7.h),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 30.h, vertical: 1.v),
                                      decoration: AppDecoration.outlinePrimary
                                          .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder15),
                                      child: Text("lbl_item".tr,
                                          style: theme.textTheme.bodyLarge)),
                                  SizedBox(height: 24.v),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                          width: 292.h,
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 30.h, vertical: 2.v),
                                          decoration: AppDecoration
                                              .outlinePrimary
                                              .copyWith(
                                                  borderRadius:
                                                      BorderRadiusStyle
                                                          .roundedBorder15),
                                          child: Text("lbl_quantity".tr,
                                              style:
                                                  theme.textTheme.bodyLarge))),
                                  SizedBox(height: 24.v),
                                  CustomElevatedButton(
                                      height: 28.v,
                                      text: "lbl_request_type".tr,
                                      margin: EdgeInsets.only(
                                          left: 11.h, right: 13.h),
                                      buttonStyle:
                                          CustomButtonStyles.outlinePrimary,
                                      buttonTextStyle:
                                          theme.textTheme.bodyLarge!,
                                      alignment: Alignment.center),
                                  SizedBox(height: 142.v),
                                  CustomElevatedButton(
                                      width: 177.h,
                                      text: "lbl_approve_request".tr,
                                      margin: EdgeInsets.only(right: 60.h),
                                      onPressed: () {
                                        onTapApproveRequest();
                                      },
                                      alignment: Alignment.centerRight)
                                ])))))));
  }

  /// Navigates to the warehouseSuccefulPageScreen when the action is triggered.
  onTapApproveRequest() {
    Get.toNamed(
      AppRoutes.warehouseSuccefulPageScreen,
    );
  }
}
