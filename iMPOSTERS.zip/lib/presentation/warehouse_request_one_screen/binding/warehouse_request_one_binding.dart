import '../controller/warehouse_request_one_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseRequestOneScreen.
///
/// This class ensures that the WarehouseRequestOneController is created when the
/// WarehouseRequestOneScreen is first loaded.
class WarehouseRequestOneBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseRequestOneController());
  }
}
