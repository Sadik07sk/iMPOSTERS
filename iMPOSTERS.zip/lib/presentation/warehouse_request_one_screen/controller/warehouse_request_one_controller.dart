import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_one_screen/models/warehouse_request_one_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseRequestOneScreen.
///
/// This class manages the state of the WarehouseRequestOneScreen, including the
/// current warehouseRequestOneModelObj
class WarehouseRequestOneController extends GetxController {
  TextEditingController nameController = TextEditingController();

  Rx<WarehouseRequestOneModel> warehouseRequestOneModelObj =
      WarehouseRequestOneModel().obs;

  @override
  void onClose() {
    super.onClose();
    nameController.dispose();
  }
}
