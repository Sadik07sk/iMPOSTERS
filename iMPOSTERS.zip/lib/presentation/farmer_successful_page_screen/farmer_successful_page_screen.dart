import 'controller/farmer_successful_page_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerSuccessfulPageScreen
    extends GetWidget<FarmerSuccessfulPageController> {
  const FarmerSuccessfulPageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 42.h, vertical: 17.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(height: 95.v),
                              CustomImageView(
                                  imagePath: ImageConstant.imgSafalFasal1,
                                  height: 219.v,
                                  width: 305.h),
                              SizedBox(height: 144.v),
                              Text("msg_request_processed".tr,
                                  style: CustomTextStyles.titleLargeSemiBold),
                              SizedBox(height: 248.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_return_to_home".tr,
                                  onPressed: () {
                                    onTapReturnToHome();
                                  }),
                              SizedBox(height: 30.v),
                              Text("lbl_contact_us".tr,
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.bodySmall)
                            ]))))));
  }

  /// Navigates to the farmerMainMenuScreen when the action is triggered.
  onTapReturnToHome() {
    Get.toNamed(
      AppRoutes.farmerMainMenuScreen,
    );
  }
}
