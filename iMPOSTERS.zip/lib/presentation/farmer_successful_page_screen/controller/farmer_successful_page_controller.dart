import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_successful_page_screen/models/farmer_successful_page_model.dart';

/// A controller class for the FarmerSuccessfulPageScreen.
///
/// This class manages the state of the FarmerSuccessfulPageScreen, including the
/// current farmerSuccessfulPageModelObj
class FarmerSuccessfulPageController extends GetxController {
  Rx<FarmerSuccessfulPageModel> farmerSuccessfulPageModelObj =
      FarmerSuccessfulPageModel().obs;
}
