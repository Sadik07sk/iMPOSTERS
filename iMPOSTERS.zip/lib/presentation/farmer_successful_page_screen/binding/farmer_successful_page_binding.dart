import '../controller/farmer_successful_page_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerSuccessfulPageScreen.
///
/// This class ensures that the FarmerSuccessfulPageController is created when the
/// FarmerSuccessfulPageScreen is first loaded.
class FarmerSuccessfulPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerSuccessfulPageController());
  }
}
