import 'controller/phone_number_one_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/core/utils/validation_functions.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class PhoneNumberOneScreen extends GetWidget<PhoneNumberOneController> {
  PhoneNumberOneScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 31.h, vertical: 54.v),
                            decoration: AppDecoration.fillGreen,
                            child: Column(children: [
                              SizedBox(height: 30.v),
                              SizedBox(
                                  height: 248.v,
                                  width: 305.h,
                                  child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgSafalFasal1,
                                            height: 219.v,
                                            width: 305.h,
                                            alignment: Alignment.topCenter),
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Text("lbl_welcome".tr,
                                                style: theme
                                                    .textTheme.displayMedium))
                                      ])),
                              SizedBox(height: 25.v),
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Opacity(
                                      opacity: 0.4,
                                      child: Padding(
                                          padding: EdgeInsets.only(left: 7.h),
                                          child: Text("lbl_create_password".tr,
                                              style: CustomTextStyles
                                                  .bodyLargeSFProDisplayPrimaryContainerLight)))),
                              SizedBox(height: 6.v),
                              CustomTextFormField(
                                  controller: controller.passwordController,
                                  hintText: "msg_enter_a_new_password".tr,
                                  hintStyle: CustomTextStyles
                                      .bodyLargeSFProDisplayLight,
                                  textInputAction: TextInputAction.done,
                                  textInputType: TextInputType.visiblePassword,
                                  validator: (value) {
                                    if (value == null ||
                                        (!isValidPassword(value,
                                            isRequired: true))) {
                                      return "err_msg_please_enter_valid_password"
                                          .tr;
                                    }
                                    return null;
                                  },
                                  obscureText: true,
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 15.h, vertical: 27.v)),
                              SizedBox(height: 78.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_create_account".tr,
                                  onPressed: () {
                                    onTapCreateAccount();
                                  }),
                              SizedBox(height: 195.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_already_have_an2".tr,
                                            style: CustomTextStyles
                                                .bodyLargeRegular),
                                        TextSpan(
                                            text: "lbl_sign_in".tr,
                                            style: CustomTextStyles
                                                .bodyLargeBlue500)
                                      ]),
                                      textAlign: TextAlign.left))
                            ])))))));
  }

  /// Navigates to the baseSelectionScreen when the action is triggered.
  onTapCreateAccount() {
    Get.toNamed(
      AppRoutes.baseSelectionScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
