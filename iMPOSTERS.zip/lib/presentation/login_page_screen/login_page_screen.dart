import 'controller/login_page_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/core/utils/validation_functions.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class LoginPageScreen extends GetWidget<LoginPageController> {
  LoginPageScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 31.h, vertical: 54.v),
                            decoration: AppDecoration.fillGreen,
                            child: Column(children: [
                              SizedBox(height: 30.v),
                              CustomImageView(
                                  imagePath: ImageConstant.imgSafalFasal1,
                                  height: 219.v,
                                  width: 305.h),
                              SizedBox(height: 8.v),
                              _buildUserProfile(),
                              SizedBox(height: 18.v),
                              Obx(() => CustomTextFormField(
                                  controller: controller.passwordController,
                                  hintText: "lbl".tr,
                                  hintStyle: CustomTextStyles
                                      .bodyLargePrimaryContainer,
                                  textInputAction: TextInputAction.done,
                                  textInputType: TextInputType.visiblePassword,
                                  prefix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                          24.h, 22.v, 8.h, 22.v),
                                      child: CustomImageView(
                                          imagePath: ImageConstant.imgVector,
                                          height: 15.adaptSize,
                                          width: 15.adaptSize)),
                                  prefixConstraints:
                                      BoxConstraints(maxHeight: 76.v),
                                  suffix: InkWell(
                                      onTap: () {
                                        controller.isShowPassword.value =
                                            !controller.isShowPassword.value;
                                      },
                                      child: Container(
                                          margin: EdgeInsets.fromLTRB(
                                              30.h, 30.v, 24.h, 23.v),
                                          child: CustomImageView(
                                              imagePath:
                                                  ImageConstant.imgSettings,
                                              height: 15.adaptSize,
                                              width: 15.adaptSize))),
                                  suffixConstraints:
                                      BoxConstraints(maxHeight: 76.v),
                                  validator: (value) {
                                    if (value == null ||
                                        (!isValidPassword(value,
                                            isRequired: true))) {
                                      return "err_msg_please_enter_valid_password"
                                          .tr;
                                    }
                                    return null;
                                  },
                                  obscureText: controller.isShowPassword.value,
                                  contentPadding:
                                      EdgeInsets.symmetric(vertical: 21.v))),
                              SizedBox(height: 18.v),
                              Align(
                                  alignment: Alignment.centerRight,
                                  child: Opacity(
                                      opacity: 0.82,
                                      child: Padding(
                                          padding: EdgeInsets.only(right: 3.h),
                                          child: Text("msg_forgot_password".tr,
                                              style: CustomTextStyles
                                                  .bodyLargeSFProDisplayPrimaryContainerRegular)))),
                              SizedBox(height: 21.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_log_in".tr,
                                  onPressed: () {
                                    onTapLOGIN();
                                  }),
                              SizedBox(height: 195.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtNoaccountsign();
                                  },
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "lbl_no_account".tr,
                                            style: CustomTextStyles
                                                .bodyLargeRegular),
                                        TextSpan(
                                            text: "lbl_sign_up".tr,
                                            style: CustomTextStyles
                                                .bodyLargeBlue700)
                                      ]),
                                      textAlign: TextAlign.left))
                            ])))))));
  }

  /// Section Widget
  Widget _buildUserProfile() {
    return Container(
        width: 328.h,
        padding: EdgeInsets.symmetric(horizontal: 15.h, vertical: 9.v),
        decoration: AppDecoration.outlinePrimary
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder15),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Opacity(
                  opacity: 0.4,
                  child: Padding(
                      padding: EdgeInsets.only(left: 6.h),
                      child: Text("lbl_phone_number".tr,
                          style:
                              CustomTextStyles.titleMediumPrimaryContainer))),
              SizedBox(height: 1.v),
              Row(children: [
                Opacity(
                    opacity: 0.92,
                    child: CustomImageView(
                        imagePath: ImageConstant.imgCall,
                        height: 24.adaptSize,
                        width: 24.adaptSize)),
                Opacity(
                    opacity: 0.76,
                    child: Padding(
                        padding: EdgeInsets.only(left: 8.h, top: 4.v),
                        child: Text("msg_enter_your_phone".tr,
                            style: CustomTextStyles
                                .bodyLargeSFProDisplayPrimaryContainer)))
              ]),
              SizedBox(height: 7.v)
            ]));
  }

  /// Navigates to the farmerMainMenuScreen when the action is triggered.
  onTapLOGIN() {
    Get.toNamed(
      AppRoutes.farmerMainMenuScreen,
    );
  }

  /// Navigates to the phoneNumberScreen when the action is triggered.
  onTapTxtNoaccountsign() {
    Get.toNamed(
      AppRoutes.phoneNumberScreen,
    );
  }
}
