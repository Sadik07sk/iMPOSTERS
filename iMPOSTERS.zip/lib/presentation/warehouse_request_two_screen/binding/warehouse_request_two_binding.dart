import '../controller/warehouse_request_two_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseRequestTwoScreen.
///
/// This class ensures that the WarehouseRequestTwoController is created when the
/// WarehouseRequestTwoScreen is first loaded.
class WarehouseRequestTwoBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseRequestTwoController());
  }
}
