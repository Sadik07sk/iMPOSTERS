import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_two_screen/models/warehouse_request_two_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseRequestTwoScreen.
///
/// This class manages the state of the WarehouseRequestTwoScreen, including the
/// current warehouseRequestTwoModelObj
class WarehouseRequestTwoController extends GetxController {
  TextEditingController nameController = TextEditingController();

  Rx<WarehouseRequestTwoModel> warehouseRequestTwoModelObj =
      WarehouseRequestTwoModel().obs;

  @override
  void onClose() {
    super.onClose();
    nameController.dispose();
  }
}
