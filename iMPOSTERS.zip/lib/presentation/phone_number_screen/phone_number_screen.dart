import 'controller/phone_number_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/core/utils/validation_functions.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class PhoneNumberScreen extends GetWidget<PhoneNumberController> {
  PhoneNumberScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 31.h, vertical: 55.v),
                            decoration: AppDecoration.fillGreen,
                            child: Column(children: [
                              SizedBox(height: 29.v),
                              SizedBox(
                                  height: 248.v,
                                  width: 305.h,
                                  child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgSafalFasal1,
                                            height: 219.v,
                                            width: 305.h,
                                            alignment: Alignment.topCenter),
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Text("lbl_welcome".tr,
                                                style: theme
                                                    .textTheme.displayMedium))
                                      ])),
                              SizedBox(height: 27.v),
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Opacity(
                                      opacity: 0.4,
                                      child: Padding(
                                          padding: EdgeInsets.only(left: 7.h),
                                          child: Text("msg_enter_your_phone".tr,
                                              style: CustomTextStyles
                                                  .bodyLargeSFProDisplayPrimaryContainerLight)))),
                              SizedBox(height: 4.v),
                              CustomTextFormField(
                                  controller: controller.phoneNumberController,
                                  hintText: "msg_enter_your_phone".tr,
                                  hintStyle: CustomTextStyles
                                      .bodyLargeSFProDisplayPrimaryContainer,
                                  textInputAction: TextInputAction.done,
                                  textInputType: TextInputType.phone,
                                  prefix: Container(
                                      margin: EdgeInsets.fromLTRB(
                                          21.h, 30.v, 7.h, 22.v),
                                      child: CustomImageView(
                                          imagePath: ImageConstant.imgCall,
                                          height: 24.adaptSize,
                                          width: 24.adaptSize)),
                                  prefixConstraints:
                                      BoxConstraints(maxHeight: 76.v),
                                  validator: (value) {
                                    if (!isValidPhone(value)) {
                                      return "err_msg_please_enter_valid_phone_number"
                                          .tr;
                                    }
                                    return null;
                                  },
                                  contentPadding: EdgeInsets.only(
                                      top: 28.v, right: 21.h, bottom: 28.v)),
                              SizedBox(height: 78.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_next".tr,
                                  onPressed: () {
                                    onTapNext();
                                  }),
                              SizedBox(height: 194.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_already_have_an2".tr,
                                            style: CustomTextStyles
                                                .bodyLargeRegular),
                                        TextSpan(
                                            text: "lbl_sign_in".tr,
                                            style: CustomTextStyles
                                                .bodyLargeBlue500)
                                      ]),
                                      textAlign: TextAlign.left))
                            ])))))));
  }

  /// Navigates to the phoneNumberOneScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.phoneNumberOneScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
