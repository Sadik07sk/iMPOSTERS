import '../farmer_store_one_screen/widgets/farmerstoreone_item_widget.dart';
import 'controller/farmer_store_one_controller.dart';
import 'models/farmerstoreone_item_model.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerStoreOneScreen extends GetWidget<FarmerStoreOneController> {
  const FarmerStoreOneScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 27.h, vertical: 67.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              SizedBox(height: 46.v),
                              CustomImageView(
                                  imagePath: ImageConstant.imgSafalFasal1,
                                  height: 219.v,
                                  width: 305.h),
                              SizedBox(height: 12.v),
                              _buildFarmerStoreOne(),
                              SizedBox(height: 116.v),
                              CustomElevatedButton(
                                  width: 177.h,
                                  text: "lbl_back".tr,
                                  onPressed: () {
                                    onTapBack();
                                  })
                            ]))))));
  }

  /// Section Widget
  Widget _buildFarmerStoreOne() {
    return Obx(() => ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (context, index) {
          return SizedBox(height: 49.v);
        },
        itemCount: controller
            .farmerStoreOneModelObj.value.farmerstoreoneItemList.value.length,
        itemBuilder: (context, index) {
          FarmerstoreoneItemModel model = controller
              .farmerStoreOneModelObj.value.farmerstoreoneItemList.value[index];
          return FarmerstoreoneItemWidget(model, onTapWarehouseCounter: () {
            onTapWarehouseCounter();
          });
        }));
  }

  /// Navigates to the warehouseOneScreen when the action is triggered.
  onTapWarehouseCounter() {
    Get.toNamed(AppRoutes.warehouseOneScreen);
  }

  /// Navigates to the farmerMainMenuScreen when the action is triggered.
  onTapBack() {
    Get.toNamed(
      AppRoutes.farmerMainMenuScreen,
    );
  }
}
