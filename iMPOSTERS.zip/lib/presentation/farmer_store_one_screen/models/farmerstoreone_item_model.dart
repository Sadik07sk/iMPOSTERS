import '../../../core/app_export.dart';

/// This class is used in the [farmerstoreone_item_widget] screen.
class FarmerstoreoneItemModel {
  FarmerstoreoneItemModel({
    this.warehouseCounter,
    this.description,
    this.id,
  }) {
    warehouseCounter = warehouseCounter ?? Rx("Warehouse 1");
    description = description ??
        Rx("Items stored- Bajra, Rice\nQuantity Stored- 10 Quintals, 8 Quintals");
    id = id ?? Rx("");
  }

  Rx<String>? warehouseCounter;

  Rx<String>? description;

  Rx<String>? id;
}
