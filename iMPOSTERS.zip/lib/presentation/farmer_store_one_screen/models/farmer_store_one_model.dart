import '../../../core/app_export.dart';
import 'farmerstoreone_item_model.dart';

/// This class defines the variables used in the [farmer_store_one_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class FarmerStoreOneModel {
  Rx<List<FarmerstoreoneItemModel>> farmerstoreoneItemList = Rx([
    FarmerstoreoneItemModel(
        warehouseCounter: "Warehouse 1".obs,
        description:
            "Items stored- Bajra, Rice\nQuantity Stored- 10 Quintals, 8 Quintals"
                .obs),
    FarmerstoreoneItemModel(
        warehouseCounter: "Warehouse 2".obs,
        description:
            "Items stored- Wheet, Rice\nQuantity Stored- 7 Quintals, 6 Quintals"
                .obs)
  ]);
}
