import '../controller/farmer_store_one_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerStoreOneScreen.
///
/// This class ensures that the FarmerStoreOneController is created when the
/// FarmerStoreOneScreen is first loaded.
class FarmerStoreOneBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerStoreOneController());
  }
}
