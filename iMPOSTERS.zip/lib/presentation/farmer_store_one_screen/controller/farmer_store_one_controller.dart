import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_store_one_screen/models/farmer_store_one_model.dart';

/// A controller class for the FarmerStoreOneScreen.
///
/// This class manages the state of the FarmerStoreOneScreen, including the
/// current farmerStoreOneModelObj
class FarmerStoreOneController extends GetxController {
  Rx<FarmerStoreOneModel> farmerStoreOneModelObj = FarmerStoreOneModel().obs;
}
