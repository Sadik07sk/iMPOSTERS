import '../controller/farmer_store_one_controller.dart';
import '../models/farmerstoreone_item_model.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class FarmerstoreoneItemWidget extends StatelessWidget {
  FarmerstoreoneItemWidget(
    this.farmerstoreoneItemModelObj, {
    Key? key,
    this.onTapWarehouseCounter,
  }) : super(
          key: key,
        );

  FarmerstoreoneItemModel farmerstoreoneItemModelObj;

  var controller = Get.find<FarmerStoreOneController>();

  VoidCallback? onTapWarehouseCounter;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTapWarehouseCounter!.call();
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 13.h,
          vertical: 12.v,
        ),
        decoration: AppDecoration.outlinePrimary1.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder6,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Obx(
              () => Text(
                farmerstoreoneItemModelObj.warehouseCounter!.value,
                style: CustomTextStyles.titleLargeSFProDisplay,
              ),
            ),
            SizedBox(height: 1.v),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "lbl_location".tr,
                    style: theme.textTheme.titleMedium,
                  ),
                  TextSpan(
                    text: "lbl_kota".tr,
                    style: CustomTextStyles.bodyLargeSFProDisplayExtraLight,
                  ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
            Container(
              width: 254.h,
              margin: EdgeInsets.only(right: 54.h),
              child: Obx(
                () => Text(
                  farmerstoreoneItemModelObj.description!.value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: CustomTextStyles.bodyLargeSFProDisplay,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
