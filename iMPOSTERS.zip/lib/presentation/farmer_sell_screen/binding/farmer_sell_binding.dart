import '../controller/farmer_sell_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerSellScreen.
///
/// This class ensures that the FarmerSellController is created when the
/// FarmerSellScreen is first loaded.
class FarmerSellBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerSellController());
  }
}
