import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_sell_screen/models/farmer_sell_model.dart';

/// A controller class for the FarmerSellScreen.
///
/// This class manages the state of the FarmerSellScreen, including the
/// current farmerSellModelObj
class FarmerSellController extends GetxController {
  Rx<FarmerSellModel> farmerSellModelObj = FarmerSellModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  SelectionPopupModel? selectedDropDownValue1;

  SelectionPopupModel? selectedDropDownValue2;

  onSelected(dynamic value) {
    for (var element in farmerSellModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerSellModelObj.value.dropdownItemList.refresh();
  }

  onSelected1(dynamic value) {
    for (var element in farmerSellModelObj.value.dropdownItemList1.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerSellModelObj.value.dropdownItemList1.refresh();
  }

  onSelected2(dynamic value) {
    for (var element in farmerSellModelObj.value.dropdownItemList2.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerSellModelObj.value.dropdownItemList2.refresh();
  }
}
