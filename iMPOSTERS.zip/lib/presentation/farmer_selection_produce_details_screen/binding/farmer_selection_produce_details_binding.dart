import '../controller/farmer_selection_produce_details_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerSelectionProduceDetailsScreen.
///
/// This class ensures that the FarmerSelectionProduceDetailsController is created when the
/// FarmerSelectionProduceDetailsScreen is first loaded.
class FarmerSelectionProduceDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerSelectionProduceDetailsController());
  }
}
