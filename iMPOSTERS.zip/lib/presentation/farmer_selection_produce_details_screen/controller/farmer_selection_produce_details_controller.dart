import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_produce_details_screen/models/farmer_selection_produce_details_model.dart';

/// A controller class for the FarmerSelectionProduceDetailsScreen.
///
/// This class manages the state of the FarmerSelectionProduceDetailsScreen, including the
/// current farmerSelectionProduceDetailsModelObj
class FarmerSelectionProduceDetailsController extends GetxController {
  Rx<FarmerSelectionProduceDetailsModel> farmerSelectionProduceDetailsModelObj =
      FarmerSelectionProduceDetailsModel().obs;

  SelectionPopupModel? selectedDropDownValue;

  onSelected(dynamic value) {
    for (var element
        in farmerSelectionProduceDetailsModelObj.value.dropdownItemList.value) {
      element.isSelected = false;
      if (element.id == value.id) {
        element.isSelected = true;
      }
    }
    farmerSelectionProduceDetailsModelObj.value.dropdownItemList.refresh();
  }
}
