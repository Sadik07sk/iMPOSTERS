import 'controller/farmer_selection_produce_details_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_drop_down.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerSelectionProduceDetailsScreen
    extends GetWidget<FarmerSelectionProduceDetailsController> {
  const FarmerSelectionProduceDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 9.h, vertical: 10.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(children: [
                          SizedBox(
                              height: 224.v,
                              width: 305.h,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgSafalFasal1,
                                        height: 219.v,
                                        width: 305.h,
                                        alignment: Alignment.center),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Text(
                                            "msg_fill_in_the_following".tr,
                                            style: CustomTextStyles
                                                .bodyLargeLight))
                                  ])),
                          SizedBox(height: 39.v),
                          Text("msg_what_do_you_mainly".tr,
                              style: theme.textTheme.bodyLarge),
                          SizedBox(height: 1.v),
                          Padding(
                              padding: EdgeInsets.symmetric(horizontal: 39.h),
                              child: CustomDropDown(
                                  icon: Container(
                                      margin: EdgeInsets.symmetric(
                                          horizontal: 17.h, vertical: 11.v),
                                      child: CustomImageView(
                                          imagePath: ImageConstant
                                              .imgVectorPrimarycontainer,
                                          height: 5.v,
                                          width: 10.h)),
                                  items: controller
                                      .farmerSelectionProduceDetailsModelObj
                                      .value
                                      .dropdownItemList!
                                      .value,
                                  onChanged: (value) {
                                    controller.onSelected(value);
                                  })),
                          SizedBox(height: 20.v),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Text("msg_how_much_do_you".tr,
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.bodyLarge)),
                          SizedBox(height: 3.v),
                          Container(
                              margin: EdgeInsets.symmetric(horizontal: 39.h),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 23.h, vertical: 4.v),
                              decoration: AppDecoration.outlinePrimary.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder15),
                              child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Opacity(
                                        opacity: 0.55,
                                        child: CustomImageView(
                                            imagePath: ImageConstant.imgSearch,
                                            height: 20.adaptSize,
                                            width: 20.adaptSize)),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 46.h, top: 3.v),
                                        child: Text("msg_enter_wright_in".tr,
                                            style: theme.textTheme.bodyMedium))
                                  ])),
                          SizedBox(height: 17.v),
                          Align(
                              alignment: Alignment.centerRight,
                              child: Text("msg_how_much_do_you2".tr,
                                  textAlign: TextAlign.center,
                                  style: theme.textTheme.bodyLarge)),
                          SizedBox(height: 6.v),
                          Container(
                              margin: EdgeInsets.only(left: 43.h, right: 35.h),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 22.h, vertical: 3.v),
                              decoration: AppDecoration.outlinePrimary.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder15),
                              child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Opacity(
                                        opacity: 0.58,
                                        child: CustomImageView(
                                            imagePath:
                                                ImageConstant.imgTdesignMoney,
                                            height: 22.v,
                                            width: 17.h)),
                                    Padding(
                                        padding: EdgeInsets.only(
                                            left: 70.h, top: 3.v, bottom: 2.v),
                                        child: Text("lbl_enter_amount".tr,
                                            style: theme.textTheme.bodyMedium))
                                  ])),
                          SizedBox(height: 44.v),
                          CustomElevatedButton(
                              width: 177.h,
                              text: "lbl_next".tr,
                              onPressed: () {
                                onTapNext();
                              }),
                          SizedBox(height: 224.v),
                          GestureDetector(
                              onTap: () {
                                onTapTxtAlreadyhavean();
                              },
                              child: RichText(
                                  text: TextSpan(children: [
                                    TextSpan(
                                        text: "msg_already_have_an2".tr,
                                        style:
                                            CustomTextStyles.bodyLargeRegular),
                                    TextSpan(
                                        text: "lbl_sign_in".tr,
                                        style:
                                            CustomTextStyles.bodyLargeBlue500)
                                  ]),
                                  textAlign: TextAlign.left)),
                          SizedBox(height: 46.v)
                        ]))))));
  }

  /// Navigates to the farmerSelectionLocationScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.farmerSelectionLocationScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
