import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_sell_customer_details_screen/models/farmer_sell_customer_details_model.dart';

/// A controller class for the FarmerSellCustomerDetailsScreen.
///
/// This class manages the state of the FarmerSellCustomerDetailsScreen, including the
/// current farmerSellCustomerDetailsModelObj
class FarmerSellCustomerDetailsController extends GetxController {
  Rx<FarmerSellCustomerDetailsModel> farmerSellCustomerDetailsModelObj =
      FarmerSellCustomerDetailsModel().obs;
}
