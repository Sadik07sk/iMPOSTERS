import '../controller/farmer_sell_customer_details_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerSellCustomerDetailsScreen.
///
/// This class ensures that the FarmerSellCustomerDetailsController is created when the
/// FarmerSellCustomerDetailsScreen is first loaded.
class FarmerSellCustomerDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerSellCustomerDetailsController());
  }
}
