import 'controller/farmer_sell_customer_details_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerSellCustomerDetailsScreen
    extends GetWidget<FarmerSellCustomerDetailsController> {
  const FarmerSellCustomerDetailsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 42.h, vertical: 62.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(height: 51.v),
                              CustomImageView(
                                  imagePath: ImageConstant.imgSafalFasal1,
                                  height: 219.v,
                                  width: 305.h),
                              SizedBox(height: 47.v),
                              _buildCustomerNameButton(),
                              SizedBox(height: 24.v),
                              _buildCustomerContactButton(),
                              SizedBox(height: 20.v),
                              _buildOrderIDButton(),
                              SizedBox(height: 243.v),
                              _buildSubmitButton()
                            ]))))));
  }

  /// Section Widget
  Widget _buildCustomerNameButton() {
    return CustomElevatedButton(
        height: 28.v,
        text: "lbl_customer_name".tr,
        margin: EdgeInsets.only(left: 2.h, right: 12.h),
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.bodyLarge!);
  }

  /// Section Widget
  Widget _buildCustomerContactButton() {
    return CustomElevatedButton(
        height: 28.v,
        text: "msg_customer_contact".tr,
        margin: EdgeInsets.only(left: 2.h, right: 12.h),
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.bodyLarge!);
  }

  /// Section Widget
  Widget _buildOrderIDButton() {
    return CustomElevatedButton(
        height: 28.v,
        text: "lbl_order_id".tr,
        margin: EdgeInsets.only(left: 2.h, right: 12.h),
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.bodyLarge!);
  }

  /// Section Widget
  Widget _buildSubmitButton() {
    return CustomElevatedButton(
        width: 177.h,
        text: "lbl_submit".tr,
        onPressed: () {
          onTapSubmitButton();
        },
        alignment: Alignment.center);
  }

  /// Navigates to the farmerSuccessfulPageScreen when the action is triggered.
  onTapSubmitButton() {
    Get.toNamed(
      AppRoutes.farmerSuccessfulPageScreen,
    );
  }
}
