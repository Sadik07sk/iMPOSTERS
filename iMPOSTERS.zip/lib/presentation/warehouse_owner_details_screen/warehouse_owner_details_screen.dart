import 'controller/warehouse_owner_details_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/core/utils/validation_functions.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class WarehouseOwnerDetailsScreen
    extends GetWidget<WarehouseOwnerDetailsController> {
  WarehouseOwnerDetailsScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 35.h, vertical: 10.v),
                            decoration: AppDecoration.fillGreen,
                            child: Column(children: [
                              SizedBox(
                                  height: 224.v,
                                  width: 305.h,
                                  child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgSafalFasal1,
                                            height: 219.v,
                                            width: 305.h,
                                            alignment: Alignment.center),
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Text(
                                                "msg_fill_in_the_following".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeLight))
                                      ])),
                              SizedBox(height: 27.v),
                              Padding(
                                  padding: EdgeInsets.only(left: 10.h),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        _buildSafalFasalOne(),
                                        _buildMaleFemaleButtons()
                                      ])),
                              SizedBox(height: 18.v),
                              _buildFullNameEditText(),
                              SizedBox(height: 16.v),
                              Container(
                                  margin: EdgeInsets.only(left: 10.h),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 30.h, vertical: 9.v),
                                  decoration: AppDecoration.outlinePrimary
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder15),
                                  child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Opacity(
                                            opacity: 0.58,
                                            child: CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgSolarCalendarBroken,
                                                height: 31.adaptSize,
                                                width: 31.adaptSize,
                                                margin:
                                                    EdgeInsets.only(top: 1.v))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: 42.h,
                                                top: 4.v,
                                                bottom: 2.v),
                                            child: Text("lbl_date_of_birth".tr,
                                                style:
                                                    theme.textTheme.titleLarge))
                                      ])),
                              SizedBox(height: 50.v),
                              _buildNextButton(),
                              SizedBox(height: 233.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_already_have_an2".tr,
                                            style: CustomTextStyles
                                                .bodyLargeRegular),
                                        TextSpan(
                                            text: "lbl_sign_in".tr,
                                            style: CustomTextStyles
                                                .bodyLargeBlue500)
                                      ]),
                                      textAlign: TextAlign.left)),
                              SizedBox(height: 52.v)
                            ])))))));
  }

  /// Section Widget
  Widget _buildSafalFasalOne() {
    return CustomElevatedButton(
        height: 50.v,
        width: 146.h,
        text: "lbl_male".tr,
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.titleLarge!);
  }

  /// Section Widget
  Widget _buildMaleFemaleButtons() {
    return CustomElevatedButton(
        height: 50.v,
        width: 144.h,
        text: "lbl_female".tr,
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.titleLarge!);
  }

  /// Section Widget
  Widget _buildFullNameEditText() {
    return Padding(
        padding: EdgeInsets.only(left: 10.h),
        child: CustomTextFormField(
            controller: controller.fullNameEditTextController,
            hintText: "lbl_full_name".tr,
            hintStyle: theme.textTheme.titleLarge!,
            textInputAction: TextInputAction.done,
            validator: (value) {
              if (!isText(value)) {
                return "err_msg_please_enter_valid_text".tr;
              }
              return null;
            },
            contentPadding:
                EdgeInsets.symmetric(horizontal: 30.h, vertical: 12.v)));
  }

  /// Section Widget
  Widget _buildNextButton() {
    return CustomElevatedButton(
        width: 177.h,
        text: "lbl_next".tr,
        onPressed: () {
          onTapNextButton();
        });
  }

  /// Navigates to the warehouseAddScreen when the action is triggered.
  onTapNextButton() {
    Get.toNamed(
      AppRoutes.warehouseAddScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
