import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_owner_details_screen/models/warehouse_owner_details_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the WarehouseOwnerDetailsScreen.
///
/// This class manages the state of the WarehouseOwnerDetailsScreen, including the
/// current warehouseOwnerDetailsModelObj
class WarehouseOwnerDetailsController extends GetxController {
  TextEditingController fullNameEditTextController = TextEditingController();

  Rx<WarehouseOwnerDetailsModel> warehouseOwnerDetailsModelObj =
      WarehouseOwnerDetailsModel().obs;

  @override
  void onClose() {
    super.onClose();
    fullNameEditTextController.dispose();
  }
}
