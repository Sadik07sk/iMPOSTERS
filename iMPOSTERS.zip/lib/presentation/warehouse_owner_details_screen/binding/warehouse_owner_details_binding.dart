import '../controller/warehouse_owner_details_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseOwnerDetailsScreen.
///
/// This class ensures that the WarehouseOwnerDetailsController is created when the
/// WarehouseOwnerDetailsScreen is first loaded.
class WarehouseOwnerDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseOwnerDetailsController());
  }
}
