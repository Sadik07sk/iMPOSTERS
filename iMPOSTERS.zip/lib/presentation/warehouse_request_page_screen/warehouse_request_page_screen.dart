import 'controller/warehouse_request_page_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class WarehouseRequestPageScreen
    extends GetWidget<WarehouseRequestPageController> {
  const WarehouseRequestPageScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 37.h, vertical: 122.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                  height: 246.v,
                                  width: 305.h,
                                  child: Stack(
                                      alignment: Alignment.bottomRight,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgSafalFasal1,
                                            height: 219.v,
                                            width: 305.h,
                                            alignment: Alignment.topCenter),
                                        Align(
                                            alignment: Alignment.bottomRight,
                                            child: Padding(
                                                padding: EdgeInsets.only(
                                                    right: 75.h),
                                                child: Text("lbl_requests".tr,
                                                    style: theme.textTheme
                                                        .headlineLarge)))
                                      ])),
                              SizedBox(height: 10.v),
                              CustomElevatedButton(
                                  height: 28.v,
                                  text: "lbl_request_1".tr,
                                  margin:
                                      EdgeInsets.only(left: 7.h, right: 17.h),
                                  buttonStyle:
                                      CustomButtonStyles.outlinePrimary,
                                  buttonTextStyle: theme.textTheme.bodyLarge!,
                                  onPressed: () {
                                    onTapRequest1();
                                  }),
                              SizedBox(height: 24.v),
                              CustomElevatedButton(
                                  height: 28.v,
                                  text: "lbl_request_2".tr,
                                  margin:
                                      EdgeInsets.only(left: 7.h, right: 17.h),
                                  buttonStyle:
                                      CustomButtonStyles.outlinePrimary,
                                  buttonTextStyle: theme.textTheme.bodyLarge!,
                                  onPressed: () {
                                    onTapRequest2();
                                  }),
                              SizedBox(height: 24.v)
                            ]))))));
  }

  /// Navigates to the warehouseRequestOneScreen when the action is triggered.
  onTapRequest1() {
    Get.toNamed(
      AppRoutes.warehouseRequestOneScreen,
    );
  }

  /// Navigates to the warehouseRequestTwoScreen when the action is triggered.
  onTapRequest2() {
    Get.toNamed(
      AppRoutes.warehouseRequestTwoScreen,
    );
  }
}
