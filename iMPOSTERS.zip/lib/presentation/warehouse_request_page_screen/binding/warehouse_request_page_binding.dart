import '../controller/warehouse_request_page_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseRequestPageScreen.
///
/// This class ensures that the WarehouseRequestPageController is created when the
/// WarehouseRequestPageScreen is first loaded.
class WarehouseRequestPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseRequestPageController());
  }
}
