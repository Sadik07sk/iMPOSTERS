import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_request_page_screen/models/warehouse_request_page_model.dart';

/// A controller class for the WarehouseRequestPageScreen.
///
/// This class manages the state of the WarehouseRequestPageScreen, including the
/// current warehouseRequestPageModelObj
class WarehouseRequestPageController extends GetxController {
  Rx<WarehouseRequestPageModel> warehouseRequestPageModelObj =
      WarehouseRequestPageModel().obs;
}
