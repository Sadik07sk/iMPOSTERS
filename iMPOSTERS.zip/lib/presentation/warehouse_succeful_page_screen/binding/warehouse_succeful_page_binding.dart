import '../controller/warehouse_succeful_page_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseSuccefulPageScreen.
///
/// This class ensures that the WarehouseSuccefulPageController is created when the
/// WarehouseSuccefulPageScreen is first loaded.
class WarehouseSuccefulPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseSuccefulPageController());
  }
}
