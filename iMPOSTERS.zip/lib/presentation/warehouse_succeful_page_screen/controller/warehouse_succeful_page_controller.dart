import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_succeful_page_screen/models/warehouse_succeful_page_model.dart';

/// A controller class for the WarehouseSuccefulPageScreen.
///
/// This class manages the state of the WarehouseSuccefulPageScreen, including the
/// current warehouseSuccefulPageModelObj
class WarehouseSuccefulPageController extends GetxController {
  Rx<WarehouseSuccefulPageModel> warehouseSuccefulPageModelObj =
      WarehouseSuccefulPageModel().obs;
}
