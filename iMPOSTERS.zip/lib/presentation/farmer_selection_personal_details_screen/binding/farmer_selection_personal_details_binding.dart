import '../controller/farmer_selection_personal_details_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerSelectionPersonalDetailsScreen.
///
/// This class ensures that the FarmerSelectionPersonalDetailsController is created when the
/// FarmerSelectionPersonalDetailsScreen is first loaded.
class FarmerSelectionPersonalDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerSelectionPersonalDetailsController());
  }
}
