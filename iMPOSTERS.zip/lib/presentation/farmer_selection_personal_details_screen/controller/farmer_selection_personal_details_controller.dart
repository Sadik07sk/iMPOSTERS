import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_personal_details_screen/models/farmer_selection_personal_details_model.dart';
import 'package:flutter/material.dart';

/// A controller class for the FarmerSelectionPersonalDetailsScreen.
///
/// This class manages the state of the FarmerSelectionPersonalDetailsScreen, including the
/// current farmerSelectionPersonalDetailsModelObj
class FarmerSelectionPersonalDetailsController extends GetxController {
  TextEditingController fullNameSectionController = TextEditingController();

  Rx<FarmerSelectionPersonalDetailsModel>
      farmerSelectionPersonalDetailsModelObj =
      FarmerSelectionPersonalDetailsModel().obs;

  @override
  void onClose() {
    super.onClose();
    fullNameSectionController.dispose();
  }
}
