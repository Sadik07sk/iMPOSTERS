import 'controller/farmer_selection_personal_details_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/core/utils/validation_functions.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:arjun_s_application3/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class FarmerSelectionPersonalDetailsScreen
    extends GetWidget<FarmerSelectionPersonalDetailsController> {
  FarmerSelectionPersonalDetailsScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: Form(
                key: _formKey,
                child: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 35.h, vertical: 10.v),
                            decoration: AppDecoration.fillGreen,
                            child: Column(children: [
                              SizedBox(
                                  height: 224.v,
                                  width: 305.h,
                                  child: Stack(
                                      alignment: Alignment.bottomCenter,
                                      children: [
                                        CustomImageView(
                                            imagePath:
                                                ImageConstant.imgSafalFasal1,
                                            height: 219.v,
                                            width: 305.h,
                                            alignment: Alignment.center),
                                        Align(
                                            alignment: Alignment.bottomCenter,
                                            child: Text(
                                                "msg_fill_in_the_following".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeLight))
                                      ])),
                              SizedBox(height: 27.v),
                              Padding(
                                  padding: EdgeInsets.only(left: 10.h),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        _buildSafalFasalOneSection(),
                                        _buildGenderSection()
                                      ])),
                              SizedBox(height: 18.v),
                              _buildFullNameSection(),
                              SizedBox(height: 16.v),
                              Container(
                                  margin: EdgeInsets.only(left: 10.h),
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 30.h, vertical: 9.v),
                                  decoration: AppDecoration.outlinePrimary
                                      .copyWith(
                                          borderRadius: BorderRadiusStyle
                                              .roundedBorder15),
                                  child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Opacity(
                                            opacity: 0.58,
                                            child: CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgSolarCalendarBroken,
                                                height: 31.adaptSize,
                                                width: 31.adaptSize,
                                                margin:
                                                    EdgeInsets.only(top: 1.v))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: 42.h,
                                                top: 4.v,
                                                bottom: 2.v),
                                            child: Text("lbl_date_of_birth".tr,
                                                style:
                                                    theme.textTheme.titleLarge))
                                      ])),
                              SizedBox(height: 50.v),
                              _buildNextButtonSection(),
                              SizedBox(height: 239.v),
                              GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: RichText(
                                      text: TextSpan(children: [
                                        TextSpan(
                                            text: "msg_already_have_an2".tr,
                                            style: CustomTextStyles
                                                .bodyLargeRegular),
                                        TextSpan(
                                            text: "lbl_sign_in".tr,
                                            style: CustomTextStyles
                                                .bodyLargeBlue500)
                                      ]),
                                      textAlign: TextAlign.left)),
                              SizedBox(height: 46.v)
                            ])))))));
  }

  /// Section Widget
  Widget _buildSafalFasalOneSection() {
    return CustomElevatedButton(
        height: 50.v,
        width: 146.h,
        text: "lbl_male".tr,
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.titleLarge!);
  }

  /// Section Widget
  Widget _buildGenderSection() {
    return CustomElevatedButton(
        height: 50.v,
        width: 144.h,
        text: "lbl_female".tr,
        buttonStyle: CustomButtonStyles.outlinePrimary,
        buttonTextStyle: theme.textTheme.titleLarge!);
  }

  /// Section Widget
  Widget _buildFullNameSection() {
    return Padding(
        padding: EdgeInsets.only(left: 10.h),
        child: CustomTextFormField(
            controller: controller.fullNameSectionController,
            hintText: "lbl_full_name".tr,
            hintStyle: theme.textTheme.titleLarge!,
            textInputAction: TextInputAction.done,
            validator: (value) {
              if (!isText(value)) {
                return "err_msg_please_enter_valid_text".tr;
              }
              return null;
            },
            contentPadding:
                EdgeInsets.symmetric(horizontal: 30.h, vertical: 12.v)));
  }

  /// Section Widget
  Widget _buildNextButtonSection() {
    return CustomElevatedButton(
        width: 177.h,
        text: "lbl_next".tr,
        onPressed: () {
          onTapNextButtonSection();
        });
  }

  /// Navigates to the farmerSelectionProduceDetailsScreen when the action is triggered.
  onTapNextButtonSection() {
    Get.toNamed(
      AppRoutes.farmerSelectionProduceDetailsScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
