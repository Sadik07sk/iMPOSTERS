import 'controller/app_navigation_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class AppNavigationScreen extends GetWidget<AppNavigationController> {
  const AppNavigationScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return SafeArea(
      child: Scaffold(
        backgroundColor: Color(0XFFFFFFFF),
        body: SizedBox(
          width: 375.h,
          child: Column(
            children: [
              _buildAppNavigation(),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0XFFFFFFFF),
                    ),
                    child: Column(
                      children: [
                        _buildScreenTitle(
                          screenTitle: "Login Page".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.loginPageScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Store One".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.farmerStoreOneScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Main menu".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.farmerMainMenuScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Store".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.farmerStoreScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Sell".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.farmerSellScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Sell Customer Details".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.farmerSellCustomerDetailsScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Successful page".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.farmerSuccessfulPageScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Phone Number".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.phoneNumberScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Phone Number One".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.phoneNumberOneScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Base Selection".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.baseSelectionScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Selection (Personal Details)".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.farmerSelectionPersonalDetailsScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Selection (Produce Details)".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.farmerSelectionProduceDetailsScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Farmer Selection (Location)".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.farmerSelectionLocationScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Owner details".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseOwnerDetailsScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Add".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.warehouseAddScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Details (ADD)".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseDetailsAddScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Location".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseLocationScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Menu".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.warehouseMenuScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse One".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.warehouseOneScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Two".tr,
                          onTapScreenTitle: () =>
                              onTapScreenTitle(AppRoutes.warehouseTwoScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Request Page".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseRequestPageScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Request One".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseRequestOneScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Request Two".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseRequestTwoScreen),
                        ),
                        _buildScreenTitle(
                          screenTitle: "Warehouse Succeful Page".tr,
                          onTapScreenTitle: () => onTapScreenTitle(
                              AppRoutes.warehouseSuccefulPageScreen),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildAppNavigation() {
    return Container(
      decoration: BoxDecoration(
        color: Color(0XFFFFFFFF),
      ),
      child: Column(
        children: [
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.h),
              child: Text(
                "App Navigation".tr,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF000000),
                  fontSize: 20.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 10.v),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: EdgeInsets.only(left: 20.h),
              child: Text(
                "Check your app's UI from the below demo screens of your app."
                    .tr,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0XFF888888),
                  fontSize: 16.fSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
          SizedBox(height: 5.v),
          Divider(
            height: 1.v,
            thickness: 1.v,
            color: Color(0XFF000000),
          ),
        ],
      ),
    );
  }

  /// Common widget
  Widget _buildScreenTitle({
    required String screenTitle,
    Function? onTapScreenTitle,
  }) {
    return GestureDetector(
      onTap: () {
        onTapScreenTitle!.call();
      },
      child: Container(
        decoration: BoxDecoration(
          color: Color(0XFFFFFFFF),
        ),
        child: Column(
          children: [
            SizedBox(height: 10.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.h),
                child: Text(
                  screenTitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0XFF000000),
                    fontSize: 20.fSize,
                    fontFamily: 'Roboto',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
            SizedBox(height: 10.v),
            SizedBox(height: 5.v),
            Divider(
              height: 1.v,
              thickness: 1.v,
              color: Color(0XFF888888),
            ),
          ],
        ),
      ),
    );
  }

  /// Common click event
  void onTapScreenTitle(String routeName) {
    Get.toNamed(routeName);
  }
}
