import '../controller/warehouse_menu_controller.dart';
import '../models/warehousemenusection_item_model.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class WarehousemenusectionItemWidget extends StatelessWidget {
  WarehousemenusectionItemWidget(
    this.warehousemenusectionItemModelObj, {
    Key? key,
    this.onTapWarehouseCounter,
  }) : super(
          key: key,
        );

  WarehousemenusectionItemModel warehousemenusectionItemModelObj;

  var controller = Get.find<WarehouseMenuController>();

  VoidCallback? onTapWarehouseCounter;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTapWarehouseCounter!.call();
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 13.h,
          vertical: 12.v,
        ),
        decoration: AppDecoration.outlinePrimary1.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder6,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 1.h),
              child: Obx(
                () => Text(
                  warehousemenusectionItemModelObj.warehouseCounter!.value,
                  style: CustomTextStyles.titleLargeSFProDisplay,
                ),
              ),
            ),
            SizedBox(height: 8.v),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: "lbl_location".tr,
                    style: theme.textTheme.titleMedium,
                  ),
                  TextSpan(
                    text: "lbl_kota".tr,
                    style: CustomTextStyles.bodyLargeSFProDisplayExtraLight,
                  ),
                ],
              ),
              textAlign: TextAlign.left,
            ),
            SizedBox(height: 2.v),
            Padding(
              padding: EdgeInsets.only(left: 1.h),
              child: Obx(
                () => Text(
                  warehousemenusectionItemModelObj.view!.value,
                  style: CustomTextStyles.bodyLargeSFProDisplay,
                ),
              ),
            ),
            SizedBox(height: 9.v),
          ],
        ),
      ),
    );
  }
}
