import '../warehouse_menu_screen/widgets/warehousemenusection_item_widget.dart';
import 'controller/warehouse_menu_controller.dart';
import 'models/warehousemenusection_item_model.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class WarehouseMenuScreen extends GetWidget<WarehouseMenuController> {
  const WarehouseMenuScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(vertical: 16.v),
                child: Column(children: [
                  CustomImageView(
                      imagePath: ImageConstant.imgJamMenu,
                      height: 43.v,
                      width: 44.h,
                      alignment: Alignment.centerLeft,
                      margin: EdgeInsets.only(left: 10.h)),
                  SizedBox(height: 37.v),
                  _buildWelcomeBackSection(),
                  SizedBox(height: 18.v),
                  CustomElevatedButton(
                      height: 39.v,
                      text: "lbl_your_warehouses".tr,
                      margin: EdgeInsets.only(left: 61.h, right: 50.h),
                      buttonStyle: CustomButtonStyles.outlinePrimaryTL6,
                      buttonTextStyle: theme.textTheme.titleLarge!),
                  SizedBox(height: 18.v),
                  _buildWarehouseMenuSection(),
                  SizedBox(height: 31.v),
                  CustomElevatedButton(
                      height: 39.v,
                      text: "lbl_view_requests".tr,
                      margin: EdgeInsets.only(left: 66.h, right: 45.h),
                      buttonStyle: CustomButtonStyles.outlinePrimaryTL6,
                      buttonTextStyle: theme.textTheme.titleLarge!,
                      onPressed: () {
                        onTapViewRequests();
                      },
                      alignment: Alignment.centerRight),
                  SizedBox(height: 20.v),
                  CustomImageView(
                      imagePath:
                          ImageConstant.imgSafalFasalRemovebgPreview66x390,
                      height: 66.v,
                      width: 390.h),
                  SizedBox(height: 5.v)
                ]))));
  }

  /// Section Widget
  Widget _buildWelcomeBackSection() {
    return Container(
        width: 335.h,
        margin: EdgeInsets.symmetric(horizontal: 27.h),
        padding: EdgeInsets.symmetric(horizontal: 19.h, vertical: 40.v),
        decoration: AppDecoration.outlinePrimary2
            .copyWith(borderRadius: BorderRadiusStyle.roundedBorder6),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("lbl_welcome_back".tr, style: theme.textTheme.displaySmall),
              Text("lbl_warehouse".tr,
                  style: CustomTextStyles.headlineLargeSFProDisplay),
              SizedBox(height: 10.v),
              Text("msg_we_hope_you_have2".tr,
                  style: CustomTextStyles.titleLargeSFProDisplay)
            ]));
  }

  /// Section Widget
  Widget _buildWarehouseMenuSection() {
    return Padding(
        padding: EdgeInsets.only(left: 32.h, right: 22.h),
        child: Obx(() => ListView.separated(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) {
              return SizedBox(height: 12.v);
            },
            itemCount: controller.warehouseMenuModelObj.value
                .warehousemenusectionItemList.value.length,
            itemBuilder: (context, index) {
              WarehousemenusectionItemModel model = controller
                  .warehouseMenuModelObj
                  .value
                  .warehousemenusectionItemList
                  .value[index];
              return WarehousemenusectionItemWidget(model,
                  onTapWarehouseCounter: () {
                onTapWarehouseCounter();
              });
            })));
  }

  /// Navigates to the warehouseOneScreen when the action is triggered.
  onTapWarehouseCounter() {
    Get.toNamed(AppRoutes.warehouseOneScreen);
  }

  /// Navigates to the warehouseRequestPageScreen when the action is triggered.
  onTapViewRequests() {
    Get.toNamed(
      AppRoutes.warehouseRequestPageScreen,
    );
  }
}
