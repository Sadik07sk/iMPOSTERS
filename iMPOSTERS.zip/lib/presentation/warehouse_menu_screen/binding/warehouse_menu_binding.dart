import '../controller/warehouse_menu_controller.dart';
import 'package:get/get.dart';

/// A binding class for the WarehouseMenuScreen.
///
/// This class ensures that the WarehouseMenuController is created when the
/// WarehouseMenuScreen is first loaded.
class WarehouseMenuBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => WarehouseMenuController());
  }
}
