import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/warehouse_menu_screen/models/warehouse_menu_model.dart';

/// A controller class for the WarehouseMenuScreen.
///
/// This class manages the state of the WarehouseMenuScreen, including the
/// current warehouseMenuModelObj
class WarehouseMenuController extends GetxController {
  Rx<WarehouseMenuModel> warehouseMenuModelObj = WarehouseMenuModel().obs;
}
