import '../../../core/app_export.dart';

/// This class is used in the [warehousemenusection_item_widget] screen.
class WarehousemenusectionItemModel {
  WarehousemenusectionItemModel({
    this.warehouseCounter,
    this.view,
    this.id,
  }) {
    warehouseCounter = warehouseCounter ?? Rx("Warehouse 1");
    view = view ?? Rx("View");
    id = id ?? Rx("");
  }

  Rx<String>? warehouseCounter;

  Rx<String>? view;

  Rx<String>? id;
}
