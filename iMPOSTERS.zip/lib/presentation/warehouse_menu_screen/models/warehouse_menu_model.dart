import '../../../core/app_export.dart';
import 'warehousemenusection_item_model.dart';

/// This class defines the variables used in the [warehouse_menu_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class WarehouseMenuModel {
  Rx<List<WarehousemenusectionItemModel>> warehousemenusectionItemList = Rx([
    WarehousemenusectionItemModel(
        warehouseCounter: "Warehouse 1".obs, view: "View".obs),
    WarehousemenusectionItemModel(
        warehouseCounter: "Warehouse 2".obs, view: "View".obs)
  ]);
}
