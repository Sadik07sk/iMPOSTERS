import 'controller/farmer_selection_location_controller.dart';
import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/widgets/custom_elevated_button.dart';
import 'package:flutter/material.dart';

class FarmerSelectionLocationScreen
    extends GetWidget<FarmerSelectionLocationController> {
  const FarmerSelectionLocationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            body: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                    child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 38.h, vertical: 10.v),
                        decoration: AppDecoration.fillGreen,
                        child: Column(children: [
                          SizedBox(
                              height: 224.v,
                              width: 305.h,
                              child: Stack(
                                  alignment: Alignment.bottomCenter,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgSafalFasal1,
                                        height: 219.v,
                                        width: 305.h,
                                        alignment: Alignment.center),
                                    Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Text(
                                            "msg_fill_in_the_following".tr,
                                            style: CustomTextStyles
                                                .bodyLargeLight))
                                  ])),
                          SizedBox(height: 118.v),
                          Text("msg_enter_your_location".tr,
                              style: theme.textTheme.bodyLarge),
                          SizedBox(height: 6.v),
                          Container(
                              margin: EdgeInsets.symmetric(horizontal: 11.h),
                              padding: EdgeInsets.symmetric(horizontal: 10.h),
                              decoration: AppDecoration.outlinePrimary.copyWith(
                                  borderRadius:
                                      BorderRadiusStyle.roundedBorder15),
                              child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    CustomImageView(
                                        imagePath: ImageConstant.imgLocation,
                                        height: 20.v,
                                        width: 14.h,
                                        margin: EdgeInsets.only(
                                            left: 12.h, top: 4.v, bottom: 3.v)),
                                    CustomImageView(
                                        imagePath:
                                            ImageConstant.imgMaterialSymbol,
                                        height: 24.adaptSize,
                                        width: 24.adaptSize,
                                        margin: EdgeInsets.only(top: 4.v))
                                  ])),
                          SizedBox(height: 14.v),
                          Text("msg_locate_me_automatically".tr,
                              style: CustomTextStyles.bodyLargeOnPrimary),
                          SizedBox(height: 15.v),
                          CustomElevatedButton(
                              width: 177.h,
                              text: "lbl_next".tr,
                              onPressed: () {
                                onTapNext();
                              }),
                          SizedBox(height: 275.v),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapTxtAlreadyhavean();
                                  },
                                  child: Padding(
                                      padding: EdgeInsets.only(left: 18.h),
                                      child: RichText(
                                          text: TextSpan(children: [
                                            TextSpan(
                                                text: "msg_already_have_an2".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeRegular),
                                            TextSpan(
                                                text: "lbl_sign_in".tr,
                                                style: CustomTextStyles
                                                    .bodyLargeBlue500)
                                          ]),
                                          textAlign: TextAlign.left)))),
                          SizedBox(height: 49.v)
                        ]))))));
  }

  /// Navigates to the farmerMainMenuScreen when the action is triggered.
  onTapNext() {
    Get.toNamed(
      AppRoutes.farmerMainMenuScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtAlreadyhavean() {
    Get.toNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
