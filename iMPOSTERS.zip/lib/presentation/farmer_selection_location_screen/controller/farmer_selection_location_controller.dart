import 'package:arjun_s_application3/core/app_export.dart';
import 'package:arjun_s_application3/presentation/farmer_selection_location_screen/models/farmer_selection_location_model.dart';

/// A controller class for the FarmerSelectionLocationScreen.
///
/// This class manages the state of the FarmerSelectionLocationScreen, including the
/// current farmerSelectionLocationModelObj
class FarmerSelectionLocationController extends GetxController {
  Rx<FarmerSelectionLocationModel> farmerSelectionLocationModelObj =
      FarmerSelectionLocationModel().obs;
}
