import '../controller/farmer_selection_location_controller.dart';
import 'package:get/get.dart';

/// A binding class for the FarmerSelectionLocationScreen.
///
/// This class ensures that the FarmerSelectionLocationController is created when the
/// FarmerSelectionLocationScreen is first loaded.
class FarmerSelectionLocationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => FarmerSelectionLocationController());
  }
}
